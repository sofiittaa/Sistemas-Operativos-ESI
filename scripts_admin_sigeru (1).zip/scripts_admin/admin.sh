#!/usr/bin/env bash
# ==============================================================================
# admin.sh — Script de administración del servidor SiGeRU (primera versión)
# ------------------------------------------------------------------------------
# Punto de entrada único para los módulos trabajados en esta entrega. Cada
# módulo vive en su propia carpeta y resuelve una única responsabilidad
# (usuarios/SSH en ssh/, respaldos en backup/); admin.sh no duplica esa
# lógica, solo dirige el pedido al módulo correcto. Un cambio dentro de un
# módulo no obliga a tocar los demás ni este dispatcher.
#
# Uso:
#   ./admin.sh ssh configurar
#   ./admin.sh backup ejecutar
#   ./admin.sh backup restaurar --latest | --file <archivo> | --local <ruta>
#   ./admin.sh backup rotar
#   ./admin.sh estado
#   ./admin.sh ayuda
#
# Módulos previstos para la Tercera Entrega (la letra los exige recién ahí;
# el dispatcher ya está preparado para sumarlos agregando un "case" nuevo,
# sin reestructurar nada de lo ya construido):
#   usuarios, grupos, redes, basededatos, firewall, logs
# ==============================================================================
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" &> /dev/null && pwd)"
LOG_FILE="/var/log/sigeru/admin.log"
# shellcheck source=lib/common.sh
source "${SCRIPT_DIR}/lib/common.sh"

ayuda() {
  cat <<'EOF'
Script de administración del servidor SiGeRU — primera versión
(Administración de Sistemas Operativos — Segunda Entrega)

Módulos disponibles:
  ssh configurar                                Instala y configura el servicio SSH
  backup ejecutar                               Corre un respaldo de la base de datos
  backup restaurar --latest|--file X|--local X  Restaura desde un respaldo
  backup rotar                                  Aplica la política de retención
  estado                                        Resumen del estado de cada módulo
  ayuda                                         Muestra este mensaje

Módulos previstos para la Tercera Entrega (todavía no implementados):
  usuarios, grupos, redes, basededatos, firewall, logs
EOF
}

estado() {
  echo "== Estado de los módulos de SiGeRU =="

  if grep -q "^PermitRootLogin no" /etc/ssh/sshd_config 2>/dev/null; then
    echo "[OK]   ssh:      configurado (puerto e ingreso de root revisados)."
  else
    echo "[--]   ssh:      todavía sin configurar. Corra: $0 ssh configurar"
  fi

  if [[ -f "${SCRIPT_DIR}/backup/backup.conf" ]]; then
    local ultimo
    ultimo=$(find /var/backups/sigeru/mysql -maxdepth 1 -name 'sigeru_*.sql.gz' -printf '%T@ %f\n' 2>/dev/null \
             | sort -rn | head -1 | cut -d' ' -f2)
    if [[ -n "${ultimo:-}" ]]; then
      echo "[OK]   backup:   último respaldo local: ${ultimo}."
    else
      echo "[--]   backup:   configurado, sin respaldos locales todavía. Corra: $0 backup ejecutar"
    fi
  else
    echo "[--]   backup:   backup/backup.conf no encontrado."
  fi

  echo "[--]   usuarios, grupos, redes, basededatos, firewall, logs: previstos para la Tercera Entrega."
}

[[ $# -ge 1 ]] || { ayuda; exit 1; }
MODULO="$1"; shift || true
log "INFO" "admin.sh invocado: ${MODULO} $*"

case "${MODULO}" in
  ssh)
    case "${1:-}" in
      configurar)
        "${SCRIPT_DIR}/ssh/configure_ssh.sh"
        ;;
      *) fail "Uso: $0 ssh configurar" ;;
    esac
    ;;

  backup)
    case "${1:-}" in
      ejecutar)
        "${SCRIPT_DIR}/backup/backup_db.sh"
        ;;
      restaurar)
        shift
        "${SCRIPT_DIR}/backup/restore_db.sh" "$@"
        ;;
      rotar)
        "${SCRIPT_DIR}/backup/rotate_backups.sh"
        ;;
      *) fail "Uso: $0 backup ejecutar | backup restaurar --latest | backup rotar" ;;
    esac
    ;;

  estado) estado ;;
  ayuda|-h|--help) ayuda ;;

  *)
    echo "Módulo desconocido: '${MODULO}'." >&2
    ayuda
    exit 1
    ;;
esac
