#!/usr/bin/env bash
# ==============================================================================
# restore_db.sh — Restaura la base de datos SiGeRU desde un respaldo
# ------------------------------------------------------------------------------
# Uso:
#   ./restore_db.sh --latest                 Restaura el respaldo diario más
#                                             reciente del servidor de respaldos.
#   ./restore_db.sh --file sigeru_20260101_020000.sql.gz
#                                             Restaura un respaldo puntual.
#   ./restore_db.sh --local /ruta/archivo.sql.gz
#                                             Restaura desde un archivo ya
#                                             presente en este servidor.
#
# Es una operación DESTRUCTIVA (reemplaza el contenido de la base "sigeru"),
# por lo que siempre pide confirmación explícita antes de ejecutar.
# ==============================================================================
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" &> /dev/null && pwd)"
# shellcheck source=backup.conf
source "${SCRIPT_DIR}/backup.conf"
# shellcheck source=../lib/common.sh
source "${SCRIPT_DIR}/../lib/common.sh"

trap 'fail "Falla inesperada en restore_db.sh, línea $LINENO"' ERR

SSH_Q=(-n -o BatchMode=yes -o ConnectTimeout=10)

usage() { grep '^#   ' "$0" | sed 's/^#//'; exit 1; }
[[ $# -ge 1 ]] || usage
[[ -r "${MYSQL_RESTORE_DEFAULTS_FILE}" ]] || fail "No se encuentra ${MYSQL_RESTORE_DEFAULTS_FILE} (credenciales de restauración)."

RESTORE_DIR="${BACKUP_LOCAL_DIR}/restore_tmp"
mkdir -p "${RESTORE_DIR}"
LOCAL_GZ=""

case "$1" in
  --latest)
    [[ "${BACKUP_REMOTE_ENABLED}" == "true" ]] || fail "--latest requiere BACKUP_REMOTE_ENABLED=true."
    SSH_OPTS=(-i "${BACKUP_REMOTE_SSH_KEY}" -p "${BACKUP_REMOTE_SSH_PORT}" -o BatchMode=yes -o ConnectTimeout=10)
    LATEST=$(ssh "${SSH_OPTS[@]}" "${SSH_Q[@]}" "${BACKUP_REMOTE_USER}@${BACKUP_REMOTE_HOST}" \
      "ls -1t '${BACKUP_REMOTE_DIR}/diario'/sigeru_*.sql.gz 2>/dev/null | head -n1") \
      || fail "No se pudo listar respaldos remotos."
    [[ -n "${LATEST}" ]] || fail "No hay respaldos diarios en el servidor remoto."
    log "INFO" "Respaldo más reciente detectado: $(basename "${LATEST}")"
    rsync -az -e "ssh ${SSH_OPTS[*]}" \
      "${BACKUP_REMOTE_USER}@${BACKUP_REMOTE_HOST}:${LATEST}" \
      "${BACKUP_REMOTE_USER}@${BACKUP_REMOTE_HOST}:${LATEST}.sha256" \
      "${RESTORE_DIR}/" || fail "No se pudo descargar el respaldo remoto."
    LOCAL_GZ="${RESTORE_DIR}/$(basename "${LATEST}")"
    ;;
  --file)
    [[ $# -ge 2 ]] || usage
    [[ "${BACKUP_REMOTE_ENABLED}" == "true" ]] || fail "--file requiere BACKUP_REMOTE_ENABLED=true."
    SSH_OPTS=(-i "${BACKUP_REMOTE_SSH_KEY}" -p "${BACKUP_REMOTE_SSH_PORT}" -o BatchMode=yes -o ConnectTimeout=10)
    for CARPETA in diario semanal; do
      REMOTE_PATH="${BACKUP_REMOTE_DIR}/${CARPETA}/$2"
      if ssh "${SSH_OPTS[@]}" "${SSH_Q[@]}" "${BACKUP_REMOTE_USER}@${BACKUP_REMOTE_HOST}" "[[ -f '${REMOTE_PATH}' ]]"; then
        rsync -az -e "ssh ${SSH_OPTS[*]}" \
          "${BACKUP_REMOTE_USER}@${BACKUP_REMOTE_HOST}:${REMOTE_PATH}" \
          "${BACKUP_REMOTE_USER}@${BACKUP_REMOTE_HOST}:${REMOTE_PATH}.sha256" \
          "${RESTORE_DIR}/" || fail "No se pudo descargar $2."
        LOCAL_GZ="${RESTORE_DIR}/$2"
        break
      fi
    done
    [[ -n "${LOCAL_GZ}" ]] || fail "No se encontró '$2' en diario/ ni semanal/ del servidor remoto."
    ;;
  --local)
    [[ $# -ge 2 ]] || usage
    [[ -f "$2" ]] || fail "No existe el archivo local $2."
    LOCAL_GZ="$2"
    ;;
  *) usage ;;
esac

# ---- verificación de integridad ------------------------------------------------
if [[ -f "${LOCAL_GZ}.sha256" ]]; then
  ( cd "$(dirname "${LOCAL_GZ}")" && sha256sum -c "$(basename "${LOCAL_GZ}").sha256" ) \
    || fail "Checksum inválido: el archivo de respaldo podría estar corrupto."
  log "INFO" "Checksum verificado correctamente para $(basename "${LOCAL_GZ}")."
else
  log "WARN" "No se encontró archivo .sha256 asociado; se continúa sin verificar integridad."
fi

# ---- confirmación explícita (operación destructiva) -----------------------------
echo "Se restaurará '${LOCAL_GZ}' sobre la base de datos '${DB_NAME}'."
echo "Esto REEMPLAZA los datos actuales. Esta acción no se puede deshacer."
read -r -p "Escriba CONFIRMAR para continuar: " RESPUESTA
[[ "${RESPUESTA}" == "CONFIRMAR" ]] || { log "INFO" "Restauración cancelada por el operador."; exit 1; }

# ---- restauración ----------------------------------------------------------------
log "INFO" "Iniciando restauración de '${DB_NAME}' desde $(basename "${LOCAL_GZ}")."
gunzip -c "${LOCAL_GZ}" | mysql --defaults-file="${MYSQL_RESTORE_DEFAULTS_FILE}" "${DB_NAME}" \
  || fail "La restauración falló durante la carga del dump."

log "INFO" "Restauración completada exitosamente desde $(basename "${LOCAL_GZ}")."
echo "Restauración completada. Ver detalle en ${LOG_FILE}."
exit 0
