#!/usr/bin/env bash
# ==============================================================================
# backup_db.sh — Rutina de respaldo de la base de datos SiGeRU
# ------------------------------------------------------------------------------
# Uso:      ./backup_db.sh
# Cron:     ver cron/sigeru-backup.cron
# Requiere: mysqldump, gzip, sha256sum, rsync, acceso SSH por clave pública
#           al Servidor 3 (respaldos).
#
# Qué hace, en orden:
#   1) Genera un dump consistente de la base "sigeru" (--single-transaction,
#      sin bloquear tablas en uso).
#   2) Lo comprime y calcula su checksum SHA-256 (integridad).
#   3) Lo copia al servidor de respaldos por SSH.
#   4) Verifica que la copia remota llegó íntegra comparando checksums.
#   5) Si es domingo, además guarda una copia en la carpeta "semanal"
#      (retención a largo plazo).
#   6) Registra cada paso en el log; si algo falla, corta la ejecución
#      (set -euo pipefail) y deja un registro ERROR claro.
# ==============================================================================
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" &> /dev/null && pwd)"
# shellcheck source=backup.conf
source "${SCRIPT_DIR}/backup.conf"
# shellcheck source=../lib/common.sh
source "${SCRIPT_DIR}/../lib/common.sh"

TIMESTAMP="$(date +%Y%m%d_%H%M%S)"
DOW="$(date +%u)"   # 1=lunes ... 7=domingo
DUMP_NAME="sigeru_${TIMESTAMP}.sql"
DUMP_PATH="${BACKUP_LOCAL_DIR}/${DUMP_NAME}"
GZ_PATH="${DUMP_PATH}.gz"
SHA_PATH="${GZ_PATH}.sha256"

# fail() de lib/common.sh no conoce NOTIFY_ON_FAILURE (es específico de este
# módulo); se redefine acá para agregar ese aviso sin duplicar log().
fail() {
  log "ERROR" "$*"
  if [[ "${NOTIFY_ON_FAILURE}" == "true" ]]; then
    log "ERROR" "Backup FALLIDO — revisar ${LOG_FILE}. Cron notificará según MAILTO."
  fi
  exit 1
}
trap 'fail "Falla inesperada en la línea $LINENO"' ERR

# Todas las llamadas SSH puntuales (no las de transporte de rsync) se hacen
# con -n, para no consumir la entrada estándar del script que las invoca.
SSH_Q=(-n -o BatchMode=yes -o ConnectTimeout=10)

# ---- 0) validaciones previas --------------------------------------------------
command -v mysqldump >/dev/null || fail "mysqldump no está instalado."
command -v gzip       >/dev/null || fail "gzip no está instalado."
command -v sha256sum  >/dev/null || fail "sha256sum no está instalado."
[[ -r "${MYSQL_DEFAULTS_FILE}" ]] || fail "No se encuentra ${MYSQL_DEFAULTS_FILE} (credenciales)."

mkdir -p "${BACKUP_LOCAL_DIR}"
log "INFO" "Inicio de backup de la base '${DB_NAME}'."

# ---- 1) dump consistente ------------------------------------------------------
mysqldump \
  --defaults-file="${MYSQL_DEFAULTS_FILE}" \
  --single-transaction \
  --quick \
  --routines \
  --triggers \
  --events \
  --hex-blob \
  --default-character-set=utf8mb4 \
  "${DB_NAME}" > "${DUMP_PATH}" \
  || fail "mysqldump terminó con error."

[[ -s "${DUMP_PATH}" ]] || fail "El dump se generó vacío."
log "INFO" "Dump generado: ${DUMP_PATH} ($(du -h "${DUMP_PATH}" | cut -f1))"

# ---- 2) comprimir y calcular checksum ----------------------------------------
gzip -f "${DUMP_PATH}"
sha256sum "${GZ_PATH}" > "${SHA_PATH}"
log "INFO" "Comprimido y verificado: ${GZ_PATH} ($(du -h "${GZ_PATH}" | cut -f1))"

# ---- 3) transferencia al servidor de respaldos (Servidor 3) -----------------
if [[ "${BACKUP_REMOTE_ENABLED}" == "true" ]]; then
  SSH_OPTS=(-i "${BACKUP_REMOTE_SSH_KEY}" -p "${BACKUP_REMOTE_SSH_PORT}" -o BatchMode=yes -o ConnectTimeout=10)

  ssh "${SSH_OPTS[@]}" "${SSH_Q[@]}" "${BACKUP_REMOTE_USER}@${BACKUP_REMOTE_HOST}" \
    "mkdir -p '${BACKUP_REMOTE_DIR}/diario' '${BACKUP_REMOTE_DIR}/semanal'" \
    || fail "No se pudo preparar el directorio remoto en ${BACKUP_REMOTE_HOST}."

  rsync -az -e "ssh ${SSH_OPTS[*]}" \
    "${GZ_PATH}" "${SHA_PATH}" \
    "${BACKUP_REMOTE_USER}@${BACKUP_REMOTE_HOST}:${BACKUP_REMOTE_DIR}/diario/" \
    || fail "rsync hacia ${BACKUP_REMOTE_HOST} falló."

  # ---- 4) verificación de integridad remota ----------------------------------
  REMOTE_CHECK=$(ssh "${SSH_OPTS[@]}" "${SSH_Q[@]}" "${BACKUP_REMOTE_USER}@${BACKUP_REMOTE_HOST}" \
    "cd '${BACKUP_REMOTE_DIR}/diario' && sha256sum -c '$(basename "${SHA_PATH}")' --status && echo OK") \
    || fail "La verificación de checksum remota no pasó: posible copia corrupta."
  [[ "${REMOTE_CHECK}" == "OK" ]] || fail "Checksum remoto no coincide con el local."
  log "INFO" "Copia verificada en ${BACKUP_REMOTE_HOST}:${BACKUP_REMOTE_DIR}/diario/"

  # ---- 5) copia semanal (retención a largo plazo) ----------------------------
  if [[ "${DOW}" == "7" ]]; then
    ssh "${SSH_OPTS[@]}" "${SSH_Q[@]}" "${BACKUP_REMOTE_USER}@${BACKUP_REMOTE_HOST}" \
      "cp '${BACKUP_REMOTE_DIR}/diario/$(basename "${GZ_PATH}")' '${BACKUP_REMOTE_DIR}/semanal/' && \
       cp '${BACKUP_REMOTE_DIR}/diario/$(basename "${SHA_PATH}")' '${BACKUP_REMOTE_DIR}/semanal/'" \
      || fail "No se pudo guardar la copia semanal."
    log "INFO" "Copia semanal (largo plazo) guardada."
  fi
else
  log "WARN" "BACKUP_REMOTE_ENABLED=false — el respaldo solo quedó en ${BACKUP_LOCAL_DIR} (no cumple alta disponibilidad)."
fi

log "INFO" "Backup finalizado correctamente: $(basename "${GZ_PATH}")"
exit 0
