#!/usr/bin/env bash
# ==============================================================================
# rotate_backups.sh — Aplica la política de retención de respaldos
# ------------------------------------------------------------------------------
# Elimina copias diarias con más de RETENTION_DAILY_DAYS días y copias
# semanales con más de RETENTION_WEEKLY_WEEKS semanas, tanto en el
# almacenamiento local (servidor de BD) como en el servidor de respaldos.
# Se ejecuta después de backup_db.sh (ver cron/sigeru-backup.cron).
# ==============================================================================
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" &> /dev/null && pwd)"
# shellcheck source=backup.conf
source "${SCRIPT_DIR}/backup.conf"
# shellcheck source=../lib/common.sh
source "${SCRIPT_DIR}/../lib/common.sh"

trap 'fail "Falla inesperada en rotate_backups.sh, línea $LINENO"' ERR

RETENTION_WEEKLY_DAYS=$(( RETENTION_WEEKLY_WEEKS * 7 ))

# ---- limpieza local -----------------------------------------------------------
if [[ -d "${BACKUP_LOCAL_DIR}" ]]; then
  BORRADOS_LOCAL=$(find "${BACKUP_LOCAL_DIR}" -maxdepth 1 -type f -name 'sigeru_*.sql.gz*' \
                    -mtime "+${RETENTION_DAILY_DAYS}" -print -delete | wc -l)
  log "INFO" "Rotación local: ${BORRADOS_LOCAL} archivo(s) eliminado(s) (retención ${RETENTION_DAILY_DAYS} días)."
else
  log "WARN" "No existe ${BACKUP_LOCAL_DIR}; nada que rotar localmente."
fi

# ---- limpieza remota (Servidor 3) ---------------------------------------------
if [[ "${BACKUP_REMOTE_ENABLED}" == "true" ]]; then
  SSH_OPTS=(-i "${BACKUP_REMOTE_SSH_KEY}" -p "${BACKUP_REMOTE_SSH_PORT}" -o BatchMode=yes -o ConnectTimeout=10)

  REMOTE_RESULT=$(ssh "${SSH_OPTS[@]}" "${BACKUP_REMOTE_USER}@${BACKUP_REMOTE_HOST}" bash -s -- \
    "${BACKUP_REMOTE_DIR}" "${RETENTION_DAILY_DAYS}" "${RETENTION_WEEKLY_DAYS}" <<'REMOTE_SCRIPT'
      set -euo pipefail
      DIR="$1"; DAILY_DAYS="$2"; WEEKLY_DAYS="$3"
      N1=$(find "${DIR}/diario"  -maxdepth 1 -type f -name 'sigeru_*.sql.gz*' -mtime "+${DAILY_DAYS}"  -print -delete | wc -l)
      N2=$(find "${DIR}/semanal" -maxdepth 1 -type f -name 'sigeru_*.sql.gz*' -mtime "+${WEEKLY_DAYS}" -print -delete | wc -l)
      echo "remoto_diario=${N1} remoto_semanal=${N2}"
REMOTE_SCRIPT
  ) || fail "No se pudo ejecutar la rotación remota en ${BACKUP_REMOTE_HOST}."

  log "INFO" "Rotación remota aplicada (${REMOTE_RESULT}; retención diaria ${RETENTION_DAILY_DAYS} días, semanal ${RETENTION_WEEKLY_DAYS} días)."
else
  log "WARN" "BACKUP_REMOTE_ENABLED=false — no se rota nada en el servidor de respaldos."
fi

log "INFO" "Rotación de respaldos finalizada."
exit 0
