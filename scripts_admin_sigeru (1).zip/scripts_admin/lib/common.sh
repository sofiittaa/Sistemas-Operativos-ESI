#!/usr/bin/env bash
# ==============================================================================
# common.sh — Funciones compartidas por los módulos del script de
# administración de SiGeRU (log, fail, verificaciones básicas).
# ------------------------------------------------------------------------------
# No se ejecuta solo: cada módulo lo carga con "source". Antes, backup_db.sh,
# rotate_backups.sh, restore_db.sh y configure_ssh.sh definían cada uno su
# propia copia de log()/fail(), casi idénticas entre sí. Centralizarlas acá
# es lo que hace al conjunto realmente "modular y reutilizable" (y no solo
# una carpeta con scripts sueltos): un cambio en cómo se registra un error se
# hace en un solo lugar y se refleja en todos los módulos.
#
# Cada módulo define su propia variable LOG_FILE ANTES de invocar log()/fail()
# (cada uno escribe en su propio archivo dentro de /var/log/sigeru/), así que
# este archivo no fuerza una ruta única.
# ==============================================================================

: "${LOG_FILE:=/var/log/sigeru/admin.log}"

log() {
  local nivel="$1"; shift
  mkdir -p "$(dirname "${LOG_FILE}")"
  printf '%s [%s] %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "${nivel}" "$*" | tee -a "${LOG_FILE}"
}

fail() {
  log "ERROR" "$*"
  exit 1
}

requerir_root() {
  [[ "${EUID}" -eq 0 ]] || fail "Este comando debe ejecutarse como root (sudo)."
}

requerir_comando() {
  command -v "$1" >/dev/null 2>&1 || fail "Falta el comando '$1'. Instálelo antes de continuar."
}
