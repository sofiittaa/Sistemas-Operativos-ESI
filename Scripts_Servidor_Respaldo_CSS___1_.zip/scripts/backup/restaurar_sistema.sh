#!/usr/bin/env bash
# =============================================================================
# restaurar_sistema.sh - Recupera un respaldo de sistema desde el servidor de respaldos
#   sudo ./restaurar_sistema.sh --latest [--host sigeru-server] [--destino DIR] [--aplicar]
#   sudo ./restaurar_sistema.sh --file sistema_sigeru-server_20261105_020000.tar.gz ...
# Por seguridad, por defecto SOLO descarga, verifica y descomprime en una carpeta
# aparte (--destino, por defecto /var/tmp/restauracion_sistema) para poder revisarlo.
# Con --aplicar copia el contenido sobre / (pide confirmación escribiendo SI).
# =============================================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CONF="${CONF:-$SCRIPT_DIR/sistema.conf}"
log()  { printf '%s [%s] %s\n' "$(date '+%F %T')" "$1" "${*:2}" >&2; }
fail() { log ERROR "$*"; exit 1; }

ARCHIVO=""; LATEST=false; APLICAR=false; HOST_ORIGEN="$(hostname -s)"
DESTINO_LOCAL="/var/tmp/restauracion_sistema"
while [[ $# -gt 0 ]]; do
  case "$1" in
    --latest)  LATEST=true; shift ;;
    --file)    ARCHIVO="${2:?Falta el nombre}"; shift 2 ;;
    --host)    HOST_ORIGEN="${2:?Falta el servidor}"; shift 2 ;;
    --destino) DESTINO_LOCAL="${2:?Falta la carpeta}"; shift 2 ;;
    --aplicar) APLICAR=true; shift ;;
    *) fail "Opción desconocida: $1" ;;
  esac
done
$LATEST || [[ -n $ARCHIVO ]] || fail "Indique --latest o --file NOMBRE."
[[ $EUID -eq 0 ]] || fail "Debe ejecutarse con sudo."
[[ -f $CONF ]]    || fail "No se encuentra $CONF"
# shellcheck source=/dev/null
source "$CONF"
DESTINO_PUERTO="${DESTINO_PUERTO:-22}"
SSH_OPTS=(-i "$CLAVE_SSH" -p "$DESTINO_PUERTO" -o BatchMode=yes -o StrictHostKeyChecking=accept-new -o LogLevel=ERROR)
# shellcheck disable=SC2029  # los argumentos se expanden a propósito en el cliente
remoto() { ssh -n "${SSH_OPTS[@]}" "$DESTINO_USUARIO@$DESTINO_HOST" "$@"; }

if $LATEST; then
  ARCHIVO="$(remoto ls -1t "$DESTINO_RUTA/diario/" | grep -E "^sistema_${HOST_ORIGEN}_[0-9]{8}_[0-9]{6}\.tar\.gz$" | head -1 || true)"
  [[ -n $ARCHIVO ]] || fail "No hay respaldos de sistema de '$HOST_ORIGEN' en el servidor de respaldos."
fi
log INFO "Respaldo elegido: $ARCHIVO"

TMP="$(mktemp -d /var/tmp/restaurar.XXXXXX)"; trap 'rm -rf "$TMP"' EXIT
RUTA_REMOTA="$DESTINO_RUTA/diario/$ARCHIVO"
remoto test -f "$RUTA_REMOTA" || RUTA_REMOTA="$DESTINO_RUTA/semanal/$ARCHIVO"
rsync -a -e "ssh ${SSH_OPTS[*]}" "$DESTINO_USUARIO@$DESTINO_HOST:$RUTA_REMOTA" "$TMP/" || fail "No se pudo descargar $ARCHIVO"

ESPERADO="$(remoto cat "$RUTA_REMOTA.sha256" | awk '{print $1}')"
REAL="$(sha256sum "$TMP/$ARCHIVO" | awk '{print $1}')"
[[ "$ESPERADO" == "$REAL" ]] || fail "Checksum distinto: el respaldo está dañado, pruebe con otro."
log INFO "Checksum verificado."

if $APLICAR; then
  read -r -p "Esto SOBRESCRIBE archivos del sistema con los de $ARCHIVO. Escriba SI para continuar: " r || fail "Cancelado."
  [[ $r == "SI" ]] || fail "Cancelado."
  tar -xzpf "$TMP/$ARCHIVO" -C / --exclude='metadatos'
  log INFO "Restauración aplicada sobre /. Reinicie los servicios y revise (docker compose up -d)."
else
  mkdir -p "$DESTINO_LOCAL"
  tar -xzpf "$TMP/$ARCHIVO" -C "$DESTINO_LOCAL"
  log INFO "Contenido descomprimido en $DESTINO_LOCAL (nada fue modificado en el sistema)."
fi
