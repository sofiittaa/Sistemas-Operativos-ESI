#!/usr/bin/env bash
# =============================================================================
# respaldar_sistema.sh - Respaldo completo de archivos del servidor
# Complementa a backup_db.sh (que respalda la base de datos): este guarda todo lo
# necesario para reconstruir el servidor: aplicaciones y scripts (/opt/sigeru),
# configuración (SSH, red, firewall, cron), lista de paquetes y estado de Docker.
#
# Se ejecuta en CADA servidor de origen, como administrador:
#   sudo ./respaldar_sistema.sh [-c /ruta/sistema.conf]
# Resultado en el servidor de respaldos:
#   diario/sistema_<servidor>_AAAAMMDD_HHMMSS.tar.gz  (+ .sha256)
#   semanal/ (una copia extra los domingos, como backup_db.sh)
# =============================================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CONF="$SCRIPT_DIR/sistema.conf"
LOG_FILE="${LOG_FILE:-/var/log/respaldo_sistema.log}"

# El detalle va siempre al archivo de log; a la pantalla solo si se ejecuta a mano o si es un ERROR.
# Así cron (que envía por mail todo lo que se imprime) solo avisa cuando algo falla.
log()  { local l; l="$(printf '%s [%s] %s' "$(date '+%F %T')" "$1" "${*:2}")"
         echo "$l" >> "$LOG_FILE" 2>/dev/null || true
         if [[ -t 2 || $1 == ERROR ]]; then echo "$l" >&2; fi; }
fail() { log ERROR "$*"; log ERROR "Respaldo de sistema FALLIDO - revisar $LOG_FILE"; exit 1; }

while getopts "c:" op; do
  case "$op" in c) CONF="$OPTARG" ;; *) fail "Uso: $0 [-c archivo.conf]" ;; esac
done
[[ $EUID -eq 0 ]]  || fail "Debe ejecutarse con sudo (necesita leer /etc y /opt)."
[[ -f $CONF ]]     || fail "No se encuentra $CONF (copie sistema.conf.example como sistema.conf)."
# shellcheck source=/dev/null
source "$CONF"
: "${DESTINO_HOST:?}" "${DESTINO_USUARIO:?}" "${DESTINO_RUTA:?}" "${CLAVE_SSH:?}" "${RUTAS_RESPALDAR:?}"
DESTINO_PUERTO="${DESTINO_PUERTO:-22}"; TEMP_DIR="${TEMP_DIR:-/var/tmp}"
[[ -r $CLAVE_SSH ]] || fail "No se puede leer la llave SSH: $CLAVE_SSH"

SERVIDOR="$(hostname -s)"
SELLO="$(date +%Y%m%d_%H%M%S)"
NOMBRE="sistema_${SERVIDOR}_${SELLO}.tar.gz"
STAGING="$(mktemp -d "$TEMP_DIR/respaldo_sistema.XXXXXX")"
trap 'rm -rf "$STAGING"' EXIT
SSH_OPTS=(-i "$CLAVE_SSH" -p "$DESTINO_PUERTO" -o BatchMode=yes -o StrictHostKeyChecking=accept-new -o LogLevel=ERROR)
# shellcheck disable=SC2029  # los argumentos se expanden a propósito en el cliente
remoto() { ssh -n "${SSH_OPTS[@]}" "$DESTINO_USUARIO@$DESTINO_HOST" "$@"; }

# --- 1. Metadatos: cómo estaba el servidor ----------------------------------------
mkdir -p "$STAGING/metadatos"
dpkg --get-selections > "$STAGING/metadatos/paquetes_instalados.txt" 2>/dev/null || true
{ crontab -l 2>/dev/null || true; } > "$STAGING/metadatos/crontab_root.txt"
ip -br addr > "$STAGING/metadatos/red.txt" 2>/dev/null || true
df -h > "$STAGING/metadatos/discos.txt" 2>/dev/null || true
if command -v docker >/dev/null 2>&1; then
  docker ps -a > "$STAGING/metadatos/docker_contenedores.txt" 2>/dev/null || true
  docker volume ls > "$STAGING/metadatos/docker_volumenes.txt" 2>/dev/null || true
fi

# --- 2. Rutas a respaldar (relativas a /, las que no existen se omiten) ---------------
RUTAS=()
for r in $RUTAS_RESPALDAR; do
  if [[ -e $r ]]; then RUTAS+=("${r#/}"); else log WARN "Se omite (no existe): $r"; fi
done
if [[ "${INCLUIR_VOLUMENES_DOCKER:-false}" == "true" && -d /var/lib/docker/volumes ]]; then
  RUTAS+=("var/lib/docker/volumes")
fi
[[ ${#RUTAS[@]} -gt 0 ]] || fail "No hay ninguna ruta válida para respaldar."

# --- 3. Archivo comprimido + checksum --------------------------------------------------
log INFO "Armando $NOMBRE (${#RUTAS[@]} ruta/s)"
set +e
tar -czpf "$TEMP_DIR/$NOMBRE" -C / "${RUTAS[@]}" -C "$STAGING" metadatos
rc=$?
set -e
# tar devuelve 1 si un archivo cambió mientras se leía (no es grave); 2 o más sí lo es
[[ $rc -le 1 ]] || { rm -f "$TEMP_DIR/$NOMBRE"; fail "tar terminó con error (código $rc)."; }
gzip -t "$TEMP_DIR/$NOMBRE" || fail "El archivo generado está corrupto."
( cd "$TEMP_DIR" && sha256sum "$NOMBRE" > "$NOMBRE.sha256" )
HASH_LOCAL="$(awk '{print $1}' "$TEMP_DIR/$NOMBRE.sha256")"

# --- 4. Envío al servidor de respaldos y verificación del otro lado -------------------------
log INFO "Enviando a $DESTINO_USUARIO@$DESTINO_HOST:$DESTINO_RUTA/diario/"
rsync -a -e "ssh ${SSH_OPTS[*]}" "$TEMP_DIR/$NOMBRE" "$TEMP_DIR/$NOMBRE.sha256" \
  "$DESTINO_USUARIO@$DESTINO_HOST:$DESTINO_RUTA/diario/" || fail "No se pudo enviar el respaldo."
HASH_REMOTO="$(remoto sha256sum "$DESTINO_RUTA/diario/$NOMBRE" | awk '{print $1}')"
[[ "$HASH_REMOTO" == "$HASH_LOCAL" ]] || fail "El archivo llegó dañado al servidor de respaldos (checksum distinto)."
log INFO "Envío verificado (sha256 coincide)."

# --- 5. Retención a largo plazo: copia extra los domingos -------------------------------------
if [[ "$(date +%u)" == "7" ]]; then
  remoto cp -p "$DESTINO_RUTA/diario/$NOMBRE" "$DESTINO_RUTA/diario/$NOMBRE.sha256" "$DESTINO_RUTA/semanal/"
  log INFO "Domingo: copia semanal guardada en semanal/."
fi

rm -f "$TEMP_DIR/$NOMBRE" "$TEMP_DIR/$NOMBRE.sha256"
log INFO "Respaldo de sistema completado: $NOMBRE ($(remoto stat -c %s "$DESTINO_RUTA/diario/$NOMBRE") bytes)"
