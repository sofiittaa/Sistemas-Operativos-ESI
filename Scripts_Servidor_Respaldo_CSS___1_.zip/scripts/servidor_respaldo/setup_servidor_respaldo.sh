#!/usr/bin/env bash
# =============================================================================
# setup_servidor_respaldo.sh - Prepara el servidor de respaldos de SiGeRU
# Se ejecuta UNA vez en sigeru-backup, con permisos de administrador:
#
#   sudo ./setup_servidor_respaldo.sh --origen 192.168.5.12 --origen 192.168.5.13 \
#        --clave-publica /tmp/sigeru-server.pub --clave-publica /tmp/sigeru-db.pub
#
# Qué hace, en orden:
#   1. Instala los paquetes necesarios (SSH, rsync, ufw).
#   2. Crea el usuario "respaldos" (sin contraseña) y las carpetas diario/ y semanal/.
#   3. Autoriza las llaves públicas de los servidores de origen, solo desde sus IP.
#   4. Endurece SSH para ese usuario (solo llave, sin túneles).
#   5. Configura el firewall: el puerto 22 solo se abre a los servidores de origen.
#   6. Instala las tareas programadas de rotación y verificación.
# Se puede ejecutar más de una vez sin romper nada.
# =============================================================================
set -euo pipefail

BACKUP_ROOT="${BACKUP_ROOT:-/srv/respaldos}"
BACKUP_USER="${BACKUP_USER:-respaldos}"
LOG_DIR="${LOG_DIR:-/var/log/respaldos}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

log()  { printf '%s [%s] %s\n' "$(date '+%F %T')" "$1" "${*:2}"; }
fail() { log ERROR "$*"; exit 1; }

ORIGENES=(); CLAVES=(); ADMINS=(); USAR_FIREWALL=true
while [[ $# -gt 0 ]]; do
  case "$1" in
    --origen)         ORIGENES+=("${2:?Falta la IP}"); shift 2 ;;
    --clave-publica)  CLAVES+=("${2:?Falta la llave}"); shift 2 ;;
    --admin)          ADMINS+=("${2:?Falta la IP}"); shift 2 ;;
    --sin-firewall)   USAR_FIREWALL=false; shift ;;
    -h|--help)        sed -n '2,19p' "$0"; exit 0 ;;
    *) fail "Opción desconocida: $1 (use --help)" ;;
  esac
done

[[ $EUID -eq 0 ]] || fail "Este script debe ejecutarse con sudo."
[[ ${#ORIGENES[@]} -gt 0 ]] || fail "Indique al menos un servidor de origen con --origen IP."
[[ ${#CLAVES[@]} -gt 0 ]]   || fail "Indique al menos una llave pública con --clave-publica."
ip_valida() {  # cuatro números entre 0 y 255 separados por puntos
  local o; [[ $1 =~ ^[0-9]{1,3}(\.[0-9]{1,3}){3}$ ]] || return 1
  for o in ${1//./ }; do (( 10#$o <= 255 )) || return 1; done
}
for ip in "${ORIGENES[@]}" "${ADMINS[@]}"; do ip_valida "$ip" || fail "IP inválida: $ip"; done

# Se validan las llaves antes de tocar el sistema (un archivo con la llave, o la llave como texto)
CLAVES_TXT=()
for k in "${CLAVES[@]}"; do
  if [[ -f $k ]]; then clave="$(cat "$k")"; else clave="$k"; fi
  tmp="$(mktemp)"; echo "$clave" > "$tmp"
  ssh-keygen -l -f "$tmp" >/dev/null 2>&1 || { rm -f "$tmp"; fail "Llave pública inválida: $k"; }
  rm -f "$tmp"; CLAVES_TXT+=("$clave")
done

# --- 1. Paquetes --------------------------------------------------------------
log INFO "Instalando paquetes (openssh-server, rsync, ufw)..."
export DEBIAN_FRONTEND=noninteractive
apt-get update -qq
apt-get install -y -qq openssh-server rsync ufw >/dev/null

# --- 2. Usuario y carpetas ------------------------------------------------------
if ! id "$BACKUP_USER" >/dev/null 2>&1; then
  useradd --create-home --shell /bin/bash --comment "Usuario de respaldos SiGeRU" "$BACKUP_USER"
  log INFO "Usuario $BACKUP_USER creado."
fi
passwd -l "$BACKUP_USER" >/dev/null   # sin contraseña: solo se entra con llave
mkdir -p "$BACKUP_ROOT/diario" "$BACKUP_ROOT/semanal" "$LOG_DIR"
chown -R "$BACKUP_USER:$BACKUP_USER" "$BACKUP_ROOT" "$LOG_DIR"
chmod 750 "$BACKUP_ROOT" "$BACKUP_ROOT/diario" "$BACKUP_ROOT/semanal"
log INFO "Carpetas listas en $BACKUP_ROOT (diario/, semanal/)."

# --- 3. Llaves autorizadas (solo desde las IP de origen) ------------------------
HOME_DIR="$(getent passwd "$BACKUP_USER" | cut -d: -f6)"
install -d -m 700 -o "$BACKUP_USER" -g "$BACKUP_USER" "$HOME_DIR/.ssh"
AUTH="$HOME_DIR/.ssh/authorized_keys"
touch "$AUTH"; chown "$BACKUP_USER:$BACKUP_USER" "$AUTH"; chmod 600 "$AUTH"
FROM="$(IFS=,; echo "${ORIGENES[*]}")"
for clave in "${CLAVES_TXT[@]}"; do
  cuerpo="$(echo "$clave" | awk '{print $2}')"
  if grep -qF "$cuerpo" "$AUTH"; then
    log INFO "La llave ya estaba autorizada (se omite)."
  else
    # restrict = sin terminal, sin túneles, sin agente; from = solo desde los servidores de origen
    echo "from=\"$FROM\",restrict $clave" >> "$AUTH"
    log INFO "Llave autorizada solo desde: $FROM"
  fi
done

# --- 4. Endurecimiento de SSH para este usuario ---------------------------------
CONF="/etc/ssh/sshd_config.d/60-respaldos.conf"
cat > "$CONF" << CONF_EOF
# Generado por setup_servidor_respaldo.sh
Match User $BACKUP_USER
    PasswordAuthentication no
    AuthenticationMethods publickey
    AllowTcpForwarding no
    AllowAgentForwarding no
    X11Forwarding no
    PermitTTY no
CONF_EOF
mkdir -p /run/sshd
sshd -t || fail "La configuración de SSH tiene errores; revise $CONF"
if systemctl is-active --quiet ssh 2>/dev/null; then
  systemctl reload ssh; log INFO "SSH recargado."
else
  log WARN "El servicio ssh no está activo bajo systemd; recárguelo manualmente."
fi

# --- 5. Firewall ------------------------------------------------------------------
if $USAR_FIREWALL; then
  # Si el administrador está conectado por SSH, se permite su IP para no quedar afuera.
  [[ -n "${SSH_CLIENT:-}" ]] && ADMINS+=("${SSH_CLIENT%% *}")
  ufw default deny incoming >/dev/null
  ufw default allow outgoing >/dev/null
  for ip in "${ORIGENES[@]}" "${ADMINS[@]}"; do
    ufw allow from "$ip" to any port 22 proto tcp >/dev/null
    log INFO "Firewall: SSH permitido desde $ip"
  done
  ufw --force enable >/dev/null
  log INFO "Firewall activado (todo lo demás entrante queda bloqueado)."
else
  log WARN "Firewall omitido (--sin-firewall)."
fi

# --- 6. Tareas programadas y rotación de logs --------------------------------------
cat > /etc/cron.d/sigeru-respaldos << CRON_EOF
# Servidor de respaldo SiGeRU: rotación y verificación diarias
# (los scripts escriben su log en /var/log/respaldos; cron envía mail a MAILTO solo si hay errores)
MAILTO=root
30 3 * * * $BACKUP_USER $SCRIPT_DIR/rotar_respaldos.sh
0  4 * * * $BACKUP_USER $SCRIPT_DIR/verificar_respaldos.sh
CRON_EOF
chmod 644 /etc/cron.d/sigeru-respaldos
cat > /etc/logrotate.d/sigeru-respaldos << LR_EOF
$LOG_DIR/*.log {
    weekly
    rotate 8
    compress
    missingok
    notifempty
}
LR_EOF
chmod +x "$SCRIPT_DIR"/*.sh
log INFO "Servidor de respaldo configurado. Siguiente paso: ejecutar respaldos desde los servidores de origen."
