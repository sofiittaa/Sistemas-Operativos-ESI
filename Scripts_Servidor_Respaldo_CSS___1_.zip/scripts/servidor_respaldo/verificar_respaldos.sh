#!/usr/bin/env bash
# =============================================================================
# verificar_respaldos.sh - Comprueba que los respaldos guardados sirven
#   1. Integridad: el .gz no está corrupto y coincide con su checksum (.sha256/.md5).
#   2. Vigencia: hay un respaldo de base de datos y uno de cada servidor de
#      origen con menos de 26 horas.
#   3. Espacio: el disco de respaldos no supera el 80% (aviso) ni el 90% (error).
# Deja un resumen en /var/log/respaldos/estado.txt (lo lee "admin.sh estado").
# Termina con código 1 si encuentra algún problema, para que cron avise por MAILTO.
# =============================================================================
set -uo pipefail

BACKUP_ROOT="${BACKUP_ROOT:-/srv/respaldos}"
ESTADO_FILE="${ESTADO_FILE:-/var/log/respaldos/estado.txt}"
MAX_EDAD_HORAS="${MAX_EDAD_HORAS:-26}"
LOG_FILE="${LOG_FILE:-/var/log/respaldos/verificacion.log}"
# Detalle al archivo de log; a pantalla solo si se ejecuta a mano o si es un ERROR (cron avisa solo ante fallas).
log() { local l; l="$(printf '%s [%s] %s' "$(date '+%F %T')" "$1" "${*:2}")"
        echo "$l" >> "$LOG_FILE" 2>/dev/null || true
        if [[ -t 1 || $1 == ERROR ]]; then echo "$l" >&2; fi; }

problemas=0; verificados=0
problema() { log ERROR "$*"; problemas=$((problemas + 1)); }

hash_de() {  # $1 = archivo con checksum (formato sha256sum/md5sum o solo el hash)
  awk '{print $1; exit}' "$1"
}

verificar_archivo() {
  local f="$1" esperado real prog
  if ! gzip -t "$f" 2>/dev/null; then problema "Archivo corrupto (gzip): $f"; return; fi
  if [[ -f "$f.sha256" ]]; then prog=sha256sum; esperado="$(hash_de "$f.sha256")"
  elif [[ -f "$f.md5" ]]; then prog=md5sum;    esperado="$(hash_de "$f.md5")"
  else log WARN "Sin checksum: $f"; verificados=$((verificados + 1)); return; fi
  real="$($prog "$f" | awk '{print $1}')"
  if [[ "$real" == "$esperado" ]]; then verificados=$((verificados + 1))
  else problema "El checksum no coincide: $f"; fi
}

# --- 1. Integridad -------------------------------------------------------------
for dir in diario semanal; do
  while IFS= read -r f; do verificar_archivo "$f"
  done < <(find "$BACKUP_ROOT/$dir" -maxdepth 1 -type f \( -name 'sigeru_*.sql.gz' -o -name 'sistema_*.tar.gz' \) 2>/dev/null | sort)
done

# --- 2. Vigencia ------------------------------------------------------------------
ultimo() {  # el archivo más reciente de la carpeta diario/ que cumple el patrón
  find "$BACKUP_ROOT/diario" -maxdepth 1 -type f -name "$1" -printf '%T@ %p\n' 2>/dev/null | sort -rn | head -1 | cut -d' ' -f2-
}
vigente() {  # $1 = archivo
  [[ -n "$1" && -n "$(find "$1" -mmin -$((MAX_EDAD_HORAS * 60)) -print -quit)" ]]
}
ult_db="$(ultimo 'sigeru_*.sql.gz')"
if vigente "$ult_db"; then log INFO "Base de datos vigente: $(basename "$ult_db")"
else problema "No hay respaldo de base de datos de las últimas ${MAX_EDAD_HORAS} horas."; fi

ult_sis=""
mapfile -t hosts < <(find "$BACKUP_ROOT/diario" -maxdepth 1 -type f -name 'sistema_*.tar.gz' -printf '%f\n' 2>/dev/null | sed -E 's/^sistema_(.+)_[0-9]{8}_[0-9]{6}\.tar\.gz$/\1/' | sort -u)
if [[ ${#hosts[@]} -eq 0 ]]; then log WARN "Todavía no hay respaldos de sistema (sistema_<servidor>_*.tar.gz)."; fi
for h in "${hosts[@]}"; do
  u="$(ultimo "sistema_${h}_*.tar.gz")"; ult_sis="${ult_sis:+$ult_sis, }$(basename "$u")"
  if vigente "$u"; then log INFO "Sistema de $h vigente: $(basename "$u")"
  else problema "El respaldo de sistema de $h tiene más de ${MAX_EDAD_HORAS} horas."; fi
done

# --- 3. Espacio en disco -------------------------------------------------------------
uso="$(df --output=pcent "$BACKUP_ROOT" | tail -1 | tr -dc '0-9')"
if   [[ $uso -ge 90 ]]; then problema "Disco de respaldos al ${uso}% (crítico)."
elif [[ $uso -ge 80 ]]; then log WARN "Disco de respaldos al ${uso}%."
else log INFO "Disco de respaldos al ${uso}%."; fi

# --- Resumen ------------------------------------------------------------------------
resultado="OK"; [[ $problemas -gt 0 ]] && resultado="ERROR"
mkdir -p "$(dirname "$ESTADO_FILE")" 2>/dev/null
{
  printf 'fecha="%s"\n' "$(date '+%F %T')"
  printf 'resultado="%s"\n' "$resultado"
  printf 'archivos_verificados="%s"\n' "$verificados"
  printf 'problemas="%s"\n' "$problemas"
  printf 'ultimo_base_datos="%s"\n' "$(basename "${ult_db:-ninguno}")"
  printf 'ultimo_sistema="%s"\n' "${ult_sis:-ninguno}"
  printf 'uso_disco="%s%%"\n' "$uso"
} > "$ESTADO_FILE" 2>/dev/null || log WARN "No se pudo escribir $ESTADO_FILE"
log INFO "Verificación finalizada: $resultado ($verificados archivo(s) verificados, $problemas problema(s))."
[[ $problemas -eq 0 ]]
