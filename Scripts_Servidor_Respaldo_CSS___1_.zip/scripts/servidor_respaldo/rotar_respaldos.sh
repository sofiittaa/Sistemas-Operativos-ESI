#!/usr/bin/env bash
# =============================================================================
# rotar_respaldos.sh - Aplica la política de retención en el servidor de respaldos
#   diario/  : se conservan los respaldos de los últimos 7 días
#   semanal/ : se conservan los respaldos de las últimas 4 semanas (28 días)
# Nunca borra el respaldo más reciente de cada tipo, aunque esté vencido: así una
# falla en los servidores de origen no deja al servidor de respaldo sin copias.
# Uso: ./rotar_respaldos.sh [--simular]    (--simular solo muestra qué borraría)
# =============================================================================
set -euo pipefail

BACKUP_ROOT="${BACKUP_ROOT:-/srv/respaldos}"
DIAS_DIARIO="${RETENCION_DIARIA_DIAS:-7}"
DIAS_SEMANAL="${RETENCION_SEMANAL_DIAS:-28}"
SIMULAR=false
[[ "${1:-}" == "--simular" ]] && SIMULAR=true

LOG_FILE="${LOG_FILE:-/var/log/respaldos/rotacion.log}"
# Detalle al archivo de log; a pantalla solo si se ejecuta a mano o si es un ERROR (cron avisa solo ante fallas).
log() { local l; l="$(printf '%s [%s] %s' "$(date '+%F %T')" "$1" "${*:2}")"
        echo "$l" >> "$LOG_FILE" 2>/dev/null || true
        if [[ -t 1 || $1 == ERROR ]]; then echo "$l" >&2; fi; }

# Tipos de respaldo: base de datos (sigeru_*.sql.gz) y sistema (sistema_<host>_*.tar.gz)
PATRONES=('sigeru_*.sql.gz' 'sistema_*.tar.gz')
borrados=0

procesar() {  # $1 = carpeta, $2 = días de retención
  local dir="$1" dias="$2" patron
  [[ -d $dir ]] || { log WARN "No existe $dir"; return 0; }
  for patron in "${PATRONES[@]}"; do
    local todos=() f
    # ordenados del más nuevo al más viejo
    mapfile -t todos < <(find "$dir" -maxdepth 1 -type f -name "$patron" -printf '%T@ %p\n' | sort -rn | cut -d' ' -f2-)
    [[ ${#todos[@]} -gt 1 ]] || continue
    for f in "${todos[@]:1}"; do                       # el [0] (más reciente) se conserva siempre
      if [[ -n "$(find "$f" -mmin +$((dias * 1440)) -print -quit)" ]]; then
        if $SIMULAR; then log INFO "[simulación] se borraría: $f"
        else rm -f -- "$f" "$f.sha256" "$f.md5"; log INFO "Borrado por retención: $f"; fi
        borrados=$((borrados + 1))
      fi
    done
  done
}

log INFO "Rotación iniciada (diario: ${DIAS_DIARIO} días, semanal: ${DIAS_SEMANAL} días)"
procesar "$BACKUP_ROOT/diario"  "$DIAS_DIARIO"
procesar "$BACKUP_ROOT/semanal" "$DIAS_SEMANAL"
log INFO "Rotación finalizada: $borrados archivo(s) vencido(s)."
