#!/usr/bin/env bash
# =============================================================================
# usuarios/usuarios.sh - Gestión de usuarios del servidor (se usa desde admin.sh)
#   admin.sh usuarios listar
#   admin.sh usuarios info NOMBRE
#   admin.sh usuarios crear NOMBRE [--grupo G]... [--sudo] [--clave-ssh ARCHIVO]
#   admin.sh usuarios eliminar NOMBRE [--con-home] [--si]
#   admin.sh usuarios bloquear NOMBRE | desbloquear NOMBRE
#   admin.sh usuarios clave NOMBRE          (nueva clave temporal, se cambia al ingresar)
#   admin.sh usuarios sudo dar|quitar NOMBRE
# Solo toca usuarios comunes (UID desde 1000); nunca root ni cuentas del sistema.
# =============================================================================
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=../lib/utils.sh
source "${SCRIPT_DIR}/../lib/utils.sh"

UID_MIN="$(awk '/^UID_MIN/{print $2}' /etc/login.defs 2>/dev/null || true)"; UID_MIN="${UID_MIN:-1000}"

existe()    { id "$1" >/dev/null 2>&1; }
es_comun()  { local u; u="$(id -u "$1" 2>/dev/null)" || return 1; [[ $u -ge $UID_MIN && $u -lt 60000 ]]; }
hogar_de()  { getent passwd "$1" | cut -d: -f6; }
con_sudo()  { getent group sudo | cut -d: -f4 | tr ',' '\n' | grep -vx '' || true; }

# Protecciones comunes a eliminar / bloquear / quitar sudo
proteger() {
  existe "$1" || fail "El usuario no existe: $1"
  es_comun "$1" || fail "Solo se administran usuarios comunes (UID desde $UID_MIN); '$1' es del sistema."
  [[ "$1" != "${SUDO_USER:-}" ]] || fail "No puede hacerlo sobre el usuario con el que está trabajando ($1)."
}
no_ultimo_admin() {   # evita dejar el servidor sin ningún usuario con sudo
  local n; n="$(con_sudo | grep -vxc "$1" || true)"
  [[ ${n:-0} -ge 1 ]] || fail "'$1' es el único usuario con sudo: cree otro administrador antes."
}
estado_cuenta() {
  local exp hoy; exp="$(getent shadow "$1" | cut -d: -f8)"; hoy=$(( $(date +%s) / 86400 ))
  if [[ -n $exp && $exp -le $hoy ]]; then echo "bloqueado"
  elif passwd -S "$1" 2>/dev/null | awk '{print $2}' | grep -q '^L'; then echo "clave bloqueada"
  else echo "activo"; fi
}
ultimo_acceso() { lastlog -u "$1" 2>/dev/null | awk 'NR==1{c=index($0,"Latest")} NR==2{ if ($0 ~ /Never/) print "nunca"; else print substr($0,c) }'; }

listar() {
  printf '%-16s %-6s %-28s %-16s %s\n' USUARIO UID GRUPOS ESTADO "ÚLTIMO ACCESO"
  local u
  while IFS= read -r u; do
    printf '%-16s %-6s %-28s %-16s %s\n' "$u" "$(id -u "$u")" "$(id -nG "$u" | tr ' ' ',' | cut -c1-28)" "$(estado_cuenta "$u")" "$(ultimo_acceso "$u")"
  done < <(getent passwd | awk -F: -v m="$UID_MIN" '$3>=m && $3<60000 {print $1}' | sort)
}

info() {
  existe "${1:?Falta el nombre}" || fail "El usuario no existe: $1"
  id "$1"; echo "Carpeta personal: $(hogar_de "$1")   Shell: $(getent passwd "$1" | cut -d: -f7)"
  echo "Estado: $(estado_cuenta "$1")   Último acceso: $(ultimo_acceso "$1")"
  chage -l "$1"
}

instalar_llave() {  # $1 usuario, $2 archivo con la llave pública (o la llave como texto)
  local clave tmp home; if [[ -f $2 ]]; then clave="$(cat "$2")"; else clave="$2"; fi
  tmp="$(mktemp)"; echo "$clave" > "$tmp"
  ssh-keygen -l -f "$tmp" >/dev/null 2>&1 || { rm -f "$tmp"; fail "Llave pública inválida."; }
  rm -f "$tmp"; home="$(hogar_de "$1")"
  install -d -m 700 -o "$1" -g "$1" "$home/.ssh"
  echo "$clave" >> "$home/.ssh/authorized_keys"
  chown "$1:$1" "$home/.ssh/authorized_keys"; chmod 600 "$home/.ssh/authorized_keys"
}

crear() {
  local nombre="${1:?Uso: usuarios crear NOMBRE [--grupo G] [--sudo] [--clave-ssh ARCHIVO]}"; shift
  local grupos=() dar_sudo=false llave="" pass g
  while [[ $# -gt 0 ]]; do
    case "$1" in
      --grupo) grupos+=("${2:?Falta el grupo}"); shift 2 ;;
      --sudo) dar_sudo=true; shift ;;
      --clave-ssh) llave="${2:?Falta el archivo}"; shift 2 ;;
      *) fail "Opción desconocida: $1" ;;
    esac
  done
  validar_nombre "$nombre"
  ! existe "$nombre" || fail "El usuario ya existe: $nombre"
  for g in "${grupos[@]}"; do getent group "$g" >/dev/null || fail "El grupo no existe: $g (créelo con: admin.sh grupos crear $g)"; done
  useradd --create-home --shell /bin/bash --comment "Usuario SiGeRU" "$nombre"
  pass="$(generar_clave)"
  echo "$nombre:$pass" | chpasswd
  chage -d 0 "$nombre"                       # obliga a cambiar la clave en el primer ingreso
  for g in "${grupos[@]}"; do usermod -aG "$g" "$nombre"; done
  $dar_sudo && usermod -aG sudo "$nombre"
  [[ -z $llave ]] || instalar_llave "$nombre" "$llave"
  local extra=""; ! $dar_sudo || extra=", sudo"
  auditar "usuarios: creado $nombre (grupos: ${grupos[*]:-ninguno}$extra)"
  log INFO "Usuario creado: $nombre"
  echo "Clave temporal (se debe cambiar al primer ingreso): $pass"
}

eliminar() {
  local nombre="${1:?Uso: usuarios eliminar NOMBRE [--con-home]}"; shift
  local home=false
  while [[ $# -gt 0 ]]; do
    case "$1" in --con-home) home=true; shift ;; --si) SI=true; shift ;; *) fail "Opción desconocida: $1" ;; esac
  done
  proteger "$nombre"
  if getent group sudo | cut -d: -f4 | tr ',' '\n' | grep -qx "$nombre"; then no_ultimo_admin "$nombre"; fi
  ! pgrep -u "$nombre" >/dev/null || fail "$nombre tiene procesos o sesiones abiertas; ciérrelas antes de eliminarlo."
  confirmar "Se eliminará el usuario $nombre$($home && echo ' y su carpeta personal')." "$nombre"
  if $home; then userdel -r "$nombre" 2>/dev/null || userdel "$nombre"; else userdel "$nombre"; fi
  auditar "usuarios: eliminado $nombre (con carpeta: $home)"
  log INFO "Usuario eliminado: $nombre"
}

bloquear() {
  proteger "${1:?Falta el nombre}"
  usermod -L "$1"; chage -E 0 "$1"           # clave bloqueada y cuenta vencida: tampoco entra por llave SSH
  auditar "usuarios: bloqueado $1"; log INFO "Usuario bloqueado: $1"
}
desbloquear() {
  existe "${1:?Falta el nombre}" || fail "El usuario no existe: $1"
  usermod -U "$1"; chage -E -1 "$1"
  auditar "usuarios: desbloqueado $1"; log INFO "Usuario desbloqueado: $1"
}
nueva_clave() {
  local pass; existe "${1:?Falta el nombre}" || fail "El usuario no existe: $1"
  es_comun "$1" || fail "Solo se administran usuarios comunes."
  pass="$(generar_clave)"; echo "$1:$pass" | chpasswd; chage -d 0 "$1"
  auditar "usuarios: nueva clave temporal para $1"
  echo "Clave temporal (se debe cambiar al ingresar): $pass"
}
manejar_sudo() {
  local accion="${1:-}" nombre="${2:-}"
  case "$accion" in
    dar) existe "$nombre" || fail "El usuario no existe: $nombre"; es_comun "$nombre" || fail "Solo usuarios comunes."
         usermod -aG sudo "$nombre"; auditar "usuarios: sudo otorgado a $nombre"; log INFO "$nombre ahora tiene sudo." ;;
    quitar) proteger "$nombre"; no_ultimo_admin "$nombre"
            gpasswd -d "$nombre" sudo >/dev/null; auditar "usuarios: sudo retirado a $nombre"; log INFO "$nombre ya no tiene sudo." ;;
    *) fail "Uso: usuarios sudo dar|quitar NOMBRE" ;;
  esac
}

resumen() {
  local total admins vacias
  total="$(getent passwd | awk -F: -v m="$UID_MIN" '$3>=m && $3<60000' | wc -l)"
  admins="$(con_sudo | wc -l)"
  if [[ $EUID -ne 0 ]]; then echo "[--] usuarios: $total usuario(s), $admins con sudo (ejecute con sudo para revisar contraseñas)"; return; fi
  vacias="$(awk -F: '$2=="" {print $1}' /etc/shadow | paste -sd, -)"
  if [[ -n $vacias ]]; then echo "[!!] usuarios: cuentas SIN contraseña: $vacias"
  elif [[ $admins -eq 0 ]]; then echo "[!!] usuarios: ningún usuario tiene sudo"
  else echo "[OK] usuarios: $total usuario(s) comunes, $admins con sudo, ninguno sin contraseña"; fi
}

accion="${1:-}"; [[ $# -gt 0 ]] && shift
case "$accion" in
  resumen) resumen ;;
  listar|info|crear|eliminar|bloquear|desbloquear|clave|sudo)
    exigir_root
    case "$accion" in
      listar) listar ;; info) info "$@" ;; crear) crear "$@" ;; eliminar) eliminar "$@" ;;
      bloquear) bloquear "$@" ;; desbloquear) desbloquear "$@" ;; clave) nueva_clave "$@" ;; sudo) manejar_sudo "$@" ;;
    esac ;;
  *) fail "Uso: usuarios listar | info | crear | eliminar | bloquear | desbloquear | clave | sudo" ;;
esac
