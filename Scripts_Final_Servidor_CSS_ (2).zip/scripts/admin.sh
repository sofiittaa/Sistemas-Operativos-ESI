#!/usr/bin/env bash
# =============================================================================
# admin.sh - Script maestro de administración de SiGeRU (versión final, 3ra entrega)
# Interpreta dos palabras (módulo y acción) y delega en el script del módulo.
# Para sumar un módulo basta una carpeta nueva y un "case" más en este archivo.
#
#   sudo ./admin.sh MÓDULO ACCIÓN [opciones]      sudo ./admin.sh estado      ./admin.sh ayuda
# =============================================================================
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=lib/common.sh
source "${SCRIPT_DIR}/lib/common.sh"

ayuda() {
  cat << 'AYUDA'
Uso: admin.sh MÓDULO ACCIÓN [opciones]

  usuarios   listar | info | crear | eliminar | bloquear | desbloquear | clave | sudo
  grupos     listar | miembros | crear | eliminar | agregar | quitar | inicializar
  redes      estado | puertos | conexiones | probar | verificar | hosts | hosts-agregar | configurar
  basedatos  estado | listar | tamanios | crear | eliminar | usuarios | usuario-crear |
             usuario-clave | usuario-eliminar | permisos
  firewall   estado | listar | logs | activar | desactivar | permitir | denegar | eliminar | perfil
  logs       listar | ver | errores | accesos | fallidos | buscar | auditoria | espacio | rotar |
             configurar-rotacion
  ssh        configurar
  backup     ejecutar | restaurar --latest | rotar | sistema | restaurar-sistema
  respaldos  instalar | rotar | verificar            (servidor de respaldos)
  estado     resumen de todos los módulos

Cada módulo muestra su propio uso si se lo invoca sin acción.
AYUDA
}

estado_ssh() {
  command -v sshd >/dev/null || { echo "[--] ssh: servicio no instalado"; return; }
  local cfg puerto root; cfg="$(sshd -T 2>/dev/null || true)"
  [[ -n $cfg ]] || { echo "[--] ssh: ejecute con sudo para leer la configuración"; return; }
  puerto="$(awk '$1=="port"{print $2; exit}' <<< "$cfg")"; root="$(awk '$1=="permitrootlogin"{print $2; exit}' <<< "$cfg")"
  if [[ $root == "no" ]]; then echo "[OK] ssh: configurado (puerto $puerto, ingreso de root deshabilitado)"
  else echo "[!!] ssh: ingreso de root = $root; ejecute: admin.sh ssh configurar"; fi
}

estado_backup() {
  local conf="${SCRIPT_DIR}/backup/backup.conf" dir="" ultimo=""
  # La carpeta de respaldos locales se toma de backup.conf (variable BACKUP_DIR); si no, se prueban las habituales
  # shellcheck disable=SC1090  # el archivo se calcula en tiempo de ejecución
  [[ -f $conf ]] && dir="$( (source "$conf" >/dev/null 2>&1; echo "${BACKUP_DIR:-}") || true)"
  for d in "$dir" /var/backups/sigeru /opt/sigeru/backups; do
    [[ -n $d && -d $d ]] || continue
    ultimo="$(find "$d" -maxdepth 2 -type f -name 'sigeru_*.sql.gz*' -printf '%T@ %f\n' 2>/dev/null | sort -rn | head -1 | cut -d' ' -f2-)"
    [[ -z $ultimo ]] || break
  done
  if [[ -n $ultimo ]]; then echo "[OK] backup: último respaldo local: $ultimo"; else echo "[--] backup: no se encontró ningún respaldo local (revise BACKUP_DIR en backup/backup.conf)"; fi
}

estado_respaldos() {   # solo existe en el servidor de respaldos (lo escribe verificar_respaldos.sh)
  local f="/var/log/respaldos/estado.txt"; [[ -f $f ]] || return 0
  ( # shellcheck source=/dev/null
    source "$f"
    # shellcheck disable=SC2154  # las variables vienen de estado.txt
    if [[ $resultado == "OK" ]]; then echo "[OK] respaldos: servidor de respaldos al día, ${archivos_verificados} archivos verificados, disco ${uso_disco}"
    else echo "[!!] respaldos: ${problemas} problema(s) en el servidor de respaldos; revise /var/log/respaldos/verificacion.log"; fi )
}

estado() {
  local salida m problemas
  salida="$( { estado_ssh; estado_backup
    for m in usuarios grupos redes basedatos firewall logs; do "${SCRIPT_DIR}/${m}/${m}.sh" resumen 2>&1 || echo "[!!] ${m}: el módulo terminó con error"; done
    estado_respaldos; } )"
  echo "== Estado de los módulos de SiGeRU =="; echo "$salida"
  problemas="$(grep -c '^\[!!\]' <<< "$salida" || true)"
  if [[ ${problemas:-0} -eq 0 ]]; then echo "== Todo en orden =="; else echo "== ${problemas} módulo(s) requieren atención =="; fi
}

MODULO="${1:-}"
if [[ -z $MODULO ]]; then ayuda; exit 1; fi
log INFO "admin.sh invocado: $*"
shift

case "${MODULO}" in
  ssh)
    case "${1:-}" in
      configurar) "${SCRIPT_DIR}/ssh/configure_ssh.sh" ;;
      *) fail "Uso: $0 ssh configurar" ;;
    esac
    ;;

  backup)
    case "${1:-}" in
      ejecutar) "${SCRIPT_DIR}/backup/backup_db.sh" ;;
      restaurar)
        shift
        "${SCRIPT_DIR}/backup/restore_db.sh" "$@"
        ;;
      rotar) "${SCRIPT_DIR}/backup/rotate_backups.sh" ;;
      sistema) "${SCRIPT_DIR}/backup/respaldar_sistema.sh" ;;
      restaurar-sistema)
        shift
        "${SCRIPT_DIR}/backup/restaurar_sistema.sh" "$@"
        ;;
      *) fail "Uso: $0 backup ejecutar | backup restaurar --latest | backup rotar | backup sistema | backup restaurar-sistema" ;;
    esac
    ;;

  respaldos)
    case "${1:-}" in
      instalar)
        shift
        "${SCRIPT_DIR}/servidor_respaldo/setup_servidor_respaldo.sh" "$@"
        ;;
      rotar) "${SCRIPT_DIR}/servidor_respaldo/rotar_respaldos.sh" ;;
      verificar) "${SCRIPT_DIR}/servidor_respaldo/verificar_respaldos.sh" ;;
      *) fail "Uso: $0 respaldos instalar | rotar | verificar" ;;
    esac
    ;;

  usuarios|grupos|redes|basedatos|firewall|logs)
    "${SCRIPT_DIR}/${MODULO}/${MODULO}.sh" "$@"
    ;;

  estado) estado ;;
  ayuda|-h|--help) ayuda ;;

  *)
    echo "Módulo desconocido: '${MODULO}'." >&2
    ayuda
    exit 1
    ;;
esac
