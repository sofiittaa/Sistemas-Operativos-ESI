#!/usr/bin/env bash
# =============================================================================
# lib/utils.sh - Funciones compartidas por los módulos de la Tercera Entrega
# (usuarios, grupos, redes, basedatos, firewall, logs). Cada módulo la carga con:
#     source "${SCRIPT_DIR}/../lib/utils.sh"
# Reutiliza log() y fail() de lib/common.sh; si no existieran, define equivalentes.
# =============================================================================
_UTILS_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=/dev/null
[[ -f "${_UTILS_DIR}/common.sh" ]] && source "${_UTILS_DIR}/common.sh"
declare -F log  >/dev/null || log()  { printf '%s [%s] %s\n' "$(date '+%F %T')" "$1" "${*:2}"; }
declare -F fail >/dev/null || fail() { log ERROR "$*"; exit 1; }

AUDIT_LOG="${AUDIT_LOG:-/var/log/sigeru-admin.log}"
PUERTO_NORM=""   # lo completa validar_puerto (los módulos lo leen)
SI=false   # --si salta las confirmaciones (para usar en scripts automáticos)

exigir_root() { [[ $EUID -eq 0 ]] || fail "Este comando debe ejecutarse con sudo."; }

# Deja constancia de quién hizo qué (usuario que invocó sudo, no "root")
auditar() { printf '%s %s %s\n' "$(date '+%F %T')" "${SUDO_USER:-${USER:-root}}" "$*" >> "$AUDIT_LOG" 2>/dev/null || true; }

# confirmar "mensaje" [palabra]: hay que escribir la palabra exacta (por defecto SI)
confirmar() {
  $SI && return 0
  local esperado="${2:-SI}" r
  read -r -p "$1 Escriba ${esperado} para continuar: " r || fail "Cancelado."
  [[ $r == "$esperado" ]] || fail "Cancelado."
}

validar_nombre() {   # usuarios y grupos de Linux: minúsculas, números, - y _
  [[ $1 =~ ^[a-z_][a-z0-9_-]{2,31}$ ]] || fail "Nombre inválido: '$1' (3 a 32 caracteres: minúsculas, números, - y _)."
}
validar_ip() {       # cuatro números entre 0 y 255
  local o; [[ $1 =~ ^[0-9]{1,3}(\.[0-9]{1,3}){3}$ ]] || fail "IP inválida: $1"
  for o in ${1//./ }; do (( 10#$o <= 255 )) || fail "IP inválida: $1"; done
}
validar_puerto() {   # 1-65535 con /tcp o /udp opcional; deja el resultado en PUERTO_NORM (tcp por defecto)
  local p="${1%%/*}" proto="tcp"
  [[ $1 == */* ]] && proto="${1##*/}"
  [[ $p =~ ^[0-9]{1,5}$ ]] || fail "Puerto inválido: $1"
  (( p >= 1 && p <= 65535 )) || fail "Puerto inválido: $1"
  [[ $proto == tcp || $proto == udp ]] || fail "Protocolo inválido: $proto (use tcp o udp)."
  # shellcheck disable=SC2034  # lo leen los módulos que cargan esta librería
  PUERTO_NORM="$p/$proto"
}
generar_clave() {    # clave aleatoria de 14 caracteres
  { LC_ALL=C tr -dc 'A-Za-z0-9' </dev/urandom | head -c 14; } 2>/dev/null || true
}
