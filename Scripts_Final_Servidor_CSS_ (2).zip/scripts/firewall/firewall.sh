#!/usr/bin/env bash
# =============================================================================
# firewall/firewall.sh - Gestión del firewall (ufw) del servidor (se usa desde admin.sh)
#   admin.sh firewall estado | listar | logs [N]
#   admin.sh firewall activar [--ssh-desde IP] | desactivar [--si]
#   admin.sh firewall permitir PUERTO[/tcp|udp] [--desde IP] [--nota TEXTO]
#   admin.sh firewall denegar PUERTO[/tcp|udp] [--desde IP]
#   admin.sh firewall eliminar NUMERO [--si]
#   admin.sh firewall perfil aplicaciones|basedatos|respaldos [--admin IP]... [--origen IP]... [--puerto P]... [--si]
# Perfiles (cada servidor de SiGeRU abre solo lo que necesita):
#   aplicaciones : 22 desde los administradores, 80 y 443 desde cualquier lugar (+ --puerto extra)
#   basedatos    : 22 desde los administradores, 3306 solo desde los servidores de --origen
#   respaldos    : 22 solo desde los servidores de --origen y los administradores
# =============================================================================
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=../lib/utils.sh
source "${SCRIPT_DIR}/../lib/utils.sh"

hay_ufw()   { command -v ufw >/dev/null || fail "ufw no está instalado (sudo apt install ufw)."; }
activo()    { ufw status 2>/dev/null | head -1 | grep -qx 'Status: active'; }
ssh_permitido() { ufw status 2>/dev/null | grep -Eq '(^|[^0-9])22(/tcp)?[[:space:]]+(ALLOW|LIMIT)'; }
permitir_ssh_actual() {   # evita quedarse afuera: abre el 22 a la IP desde la que se está conectado
  if [[ -n ${SSH_CLIENT:-} ]]; then ufw allow from "${SSH_CLIENT%% *}" to any port 22 proto tcp comment 'admin actual' >/dev/null; log INFO "SSH permitido desde su IP actual (${SSH_CLIENT%% *})."; fi
}

estado() { ufw status verbose; }
listar() { ufw status numbered; }

activar() {
  local ssh_desde=""
  [[ ${1:-} == "--ssh-desde" ]] && { ssh_desde="${2:?}"; validar_ip "$ssh_desde"; }
  if [[ -n $ssh_desde ]]; then ufw allow from "$ssh_desde" to any port 22 proto tcp comment 'admin' >/dev/null
  elif ! ssh_permitido; then
    if [[ -n ${SSH_CLIENT:-} ]]; then permitir_ssh_actual
    else ufw allow 22/tcp comment 'ssh' >/dev/null; log WARN "No había regla para SSH: se abrió el 22 a todo el mundo. Restrínjalo con: firewall permitir 22 --desde IP"; fi
  fi
  ufw default deny incoming >/dev/null; ufw default allow outgoing >/dev/null
  ufw logging low >/dev/null
  ufw --force enable >/dev/null
  auditar "firewall: activado"; log INFO "Firewall activado (entrada denegada por defecto)."
}
desactivar() {
  [[ ${1:-} == "--si" ]] && SI=true
  confirmar "Se DESACTIVARÁ el firewall: el servidor quedará expuesto."
  ufw --force disable >/dev/null; auditar "firewall: desactivado"; log WARN "Firewall desactivado."
}

regla() {   # regla allow|deny PUERTO [--desde IP] [--nota TXT]
  local accion="$1" puerto desde="" nota=""; shift
  validar_puerto "${1:?Falta el puerto}"; puerto="$PUERTO_NORM"; shift
  while [[ $# -gt 0 ]]; do
    case "$1" in --desde) desde="${2:?}"; validar_ip "$desde"; shift 2 ;; --nota) nota="${2:?}"; shift 2 ;; *) fail "Opción desconocida: $1" ;; esac
  done
  local args=("$accion")
  [[ -n $desde ]] && args+=(from "$desde")
  args+=(to any port "${puerto%/*}" proto "${puerto#*/}")
  [[ -z $nota ]] || args+=(comment "$nota")
  ufw "${args[@]}" >/dev/null
  auditar "firewall: $accion $puerto${desde:+ desde $desde}"; log INFO "Regla agregada: $accion $puerto${desde:+ desde $desde}"
}

eliminar() {
  local n="${1:?Uso: firewall eliminar NUMERO}"; shift
  [[ $n =~ ^[0-9]+$ ]] || fail "El número de regla debe ser numérico (vea: firewall listar)."
  [[ ${1:-} == "--si" ]] && SI=true
  local detalle; detalle="$(ufw status numbered | grep -E "^\[ *$n\]" || true)"
  [[ -n $detalle ]] || fail "No existe la regla número $n."
  confirmar "Se eliminará la regla: $detalle"
  ufw --force delete "$n" >/dev/null; auditar "firewall: eliminada regla $n ($detalle)"; log INFO "Regla eliminada."
}

perfil() {
  local rol="${1:-}"; shift || true
  local admins=() origenes=() extra=() ip p
  while [[ $# -gt 0 ]]; do
    case "$1" in
      --admin) validar_ip "${2:?}"; admins+=("$2"); shift 2 ;;
      --origen) validar_ip "${2:?}"; origenes+=("$2"); shift 2 ;;
      --puerto) validar_puerto "${2:?}"; extra+=("$PUERTO_NORM"); shift 2 ;;
      --si) SI=true; shift ;;
      *) fail "Opción desconocida: $1" ;;
    esac
  done
  [[ -z ${SSH_CLIENT:-} ]] || admins+=("${SSH_CLIENT%% *}")      # nunca quedarse afuera
  [[ ${#admins[@]} -gt 0 || $rol == respaldos ]] || fail "Indique al menos un administrador con --admin IP (para no perder el acceso SSH)."
  case "$rol" in
    aplicaciones) ;;
    basedatos)  [[ ${#origenes[@]} -gt 0 ]] || fail "El perfil basedatos necesita --origen IP (servidores de aplicaciones)." ;;
    respaldos)  [[ ${#origenes[@]} -gt 0 ]] || fail "El perfil respaldos necesita --origen IP (servidores a respaldar)." ;;
    *) fail "Perfil desconocido: '$rol' (aplicaciones | basedatos | respaldos)" ;;
  esac
  confirmar "Se REEMPLAZARÁN todas las reglas actuales por el perfil '$rol'."
  ufw --force reset >/dev/null
  ufw default deny incoming >/dev/null; ufw default allow outgoing >/dev/null
  for ip in "${admins[@]}" "${origenes[@]}"; do ufw allow from "$ip" to any port 22 proto tcp >/dev/null; done
  case "$rol" in
    aplicaciones) ufw allow 80/tcp >/dev/null; ufw allow 443/tcp >/dev/null
                  for p in "${extra[@]}"; do ufw allow "$p" >/dev/null; done ;;
    basedatos)    for ip in "${origenes[@]}"; do ufw allow from "$ip" to any port 3306 proto tcp >/dev/null; done ;;
  esac
  ufw logging low >/dev/null; ufw --force enable >/dev/null
  auditar "firewall: perfil $rol aplicado (admin: ${admins[*]:-}; origen: ${origenes[*]:-})"
  log INFO "Perfil '$rol' aplicado."; ufw status numbered
}

logs() {
  local n="${1:-30}" salida=""; [[ $n =~ ^[0-9]+$ ]] || fail "Indique cuántas líneas (número)."
  if [[ -f /var/log/ufw.log ]]; then salida="$(grep 'UFW BLOCK' /var/log/ufw.log | tail -n "$n" || true)"
  elif command -v journalctl >/dev/null; then salida="$(journalctl -k --no-pager -q 2>/dev/null | grep 'UFW BLOCK' | tail -n "$n" || true)"; fi
  if [[ -n $salida ]]; then echo "$salida"; else echo "No hay bloqueos registrados (el registro se activa con: ufw logging low)."; fi
}

resumen() {
  command -v ufw >/dev/null || { echo "[--] firewall: ufw no instalado"; return; }
  [[ $EUID -eq 0 ]] || { echo "[--] firewall: ejecute con sudo para ver el estado"; return; }
  if ! activo; then echo "[!!] firewall: ufw está INACTIVO"; return; fi
  local reglas; reglas="$(ufw status | grep -cE 'ALLOW|DENY|LIMIT' || true)"
  if ! ufw status verbose | grep -q 'deny (incoming)'; then echo "[!!] firewall: activo, pero la entrada no se deniega por defecto"
  else echo "[OK] firewall: activo, entrada denegada por defecto, $reglas regla(s)"; fi
}

accion="${1:-}"; [[ $# -gt 0 ]] && shift
case "$accion" in
  resumen) resumen ;;
  estado|listar|logs|activar|desactivar|permitir|denegar|eliminar|perfil)
    exigir_root; hay_ufw
    case "$accion" in
      estado) estado ;; listar) listar ;; logs) logs "$@" ;; activar) activar "$@" ;; desactivar) desactivar "$@" ;;
      permitir) regla allow "$@" ;; denegar) regla deny "$@" ;; eliminar) eliminar "$@" ;; perfil) perfil "$@" ;;
    esac ;;
  *) fail "Uso: firewall estado | listar | logs | activar | desactivar | permitir | denegar | eliminar | perfil" ;;
esac
