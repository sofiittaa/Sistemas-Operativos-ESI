#!/usr/bin/env bash
# =============================================================================
# logs/logs.sh - Gestión de logs del sistema (se usa desde admin.sh)
#   admin.sh logs listar                      logs principales con tamaño y fecha
#   admin.sh logs ver NOMBRE [N] [--seguir]   últimas N líneas (50 por defecto)
#   admin.sh logs errores [HORAS]             errores del sistema en las últimas HORAS (24)
#   admin.sh logs accesos [N]                 últimos ingresos al servidor
#   admin.sh logs fallidos [N]                intentos fallidos de SSH, agrupados por IP
#   admin.sh logs buscar TEXTO [NOMBRE]       busca texto en un log (por defecto, el del sistema)
#   admin.sh logs auditoria [N]               lo que se hizo con admin.sh (quién, cuándo, qué)
#   admin.sh logs espacio                     uso de disco de /var/log
#   admin.sh logs rotar [--si]                fuerza la rotación (logrotate) y limpia journald > 14 días
#   admin.sh logs configurar-rotacion         instala la rotación de los logs propios de SiGeRU
# NOMBRE: sistema, auth, firewall, kernel, admin, respaldo, servidor-respaldo, o una ruta dentro de /var/log
# =============================================================================
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=../lib/utils.sh
source "${SCRIPT_DIR}/../lib/utils.sh"
LOG_BASE="${LOG_BASE:-/var/log}"

declare -A LOGS=(
  [sistema]="$LOG_BASE/syslog"  [auth]="$LOG_BASE/auth.log"  [firewall]="$LOG_BASE/ufw.log"  [kernel]="$LOG_BASE/kern.log"
  [admin]="$AUDIT_LOG"  [respaldo]="$LOG_BASE/respaldo_sistema.log"  [servidor-respaldo]="$LOG_BASE/respaldos/verificacion.log"
)
hay_journal() { command -v journalctl >/dev/null && [[ -n "$(journalctl --no-pager -n 1 -q 2>/dev/null)" ]]; }

RUTA_LOG=""
resolver() {   # nombre o ruta -> RUTA_LOG (ruta real, siempre dentro de /var/log)
  local nombre="$1" ruta
  if [[ -n ${LOGS[$nombre]+x} ]]; then ruta="${LOGS[$nombre]}"; else ruta="$nombre"; fi
  [[ -e $ruta ]] || fail "No existe el log: $ruta"
  RUTA_LOG="$(realpath "$ruta")"
  [[ $RUTA_LOG == "$LOG_BASE"/* ]] || fail "Solo se pueden consultar archivos dentro de $LOG_BASE."
}

listar() {
  printf '%-20s %-9s %-17s %s\n' NOMBRE TAMAÑO MODIFICADO RUTA
  local n r
  for n in "${!LOGS[@]}"; do
    r="${LOGS[$n]}"; [[ -f $r ]] || continue
    printf '%-20s %-9s %-17s %s\n' "$n" "$(du -h "$r" | cut -f1)" "$(date -r "$r" '+%F %H:%M')" "$r"
  done | sort
}

ver() {
  local nombre="${1:?Uso: logs ver NOMBRE [N] [--seguir]}"; shift
  local n=50 seguir=false
  while [[ $# -gt 0 ]]; do case "$1" in --seguir) seguir=true; shift ;; *) [[ $1 =~ ^[0-9]+$ ]] || fail "Parámetro inválido: $1"; n="$1"; shift ;; esac; done
  resolver "$nombre"
  if $seguir; then tail -n "$n" -f "$RUTA_LOG"; else tail -n "$n" "$RUTA_LOG"; fi
}

errores() {
  local h="${1:-24}"; [[ $h =~ ^[0-9]+$ ]] || fail "Indique las horas como número."
  echo "== Errores del sistema en las últimas $h hora(s)"
  if hay_journal; then journalctl -p err --since "-${h}h" --no-pager -q | tail -n 40
  elif [[ -f ${LOGS[sistema]} ]]; then
    awk -v desde="$(date -d "-${h} hours" '+%Y-%m-%dT%H:%M:%S')" '$1 >= desde && tolower($0) ~ /error|fail|critical|denied/' "${LOGS[sistema]}" | tail -n 40
  else echo "No hay registros del sistema disponibles."; fi
}

accesos() { local n="${1:-15}"; [[ $n =~ ^[0-9]+$ ]] || fail "Indique un número."; echo "== Últimos $n ingresos"; last -n "$n" -a 2>/dev/null || echo "No hay registro de ingresos."; }

lineas_auth() {  # intentos de SSH: del log de autenticación o, si no existe, del journal
  if [[ -f ${LOGS[auth]} ]]; then cat "${LOGS[auth]}"
  elif hay_journal; then journalctl -u ssh -u sshd --no-pager -q
  fi
}
fallidos() {
  local n="${1:-10}"; [[ $n =~ ^[0-9]+$ ]] || fail "Indique un número."
  echo "== Intentos fallidos de SSH por IP (top $n)"
  lineas_auth | grep -E 'Failed password|Invalid user' | grep -oE 'from [0-9]{1,3}(\.[0-9]{1,3}){3}' | awk '{print $2}' | sort | uniq -c | sort -rn | head -n "$n" || true
}

buscar() {
  local texto="${1:?Uso: logs buscar TEXTO [NOMBRE]}" res
  resolver "${2:-sistema}"
  res="$(grep -I -n -i -F -e "$texto" "$RUTA_LOG" | tail -n 100 || true)"
  if [[ -n $res ]]; then echo "$res"; else echo "Sin resultados."; fi
}

auditoria() { local n="${1:-30}"; [[ $n =~ ^[0-9]+$ ]] || fail "Indique un número."; [[ -f $AUDIT_LOG ]] || fail "Todavía no hay registro de auditoría."; tail -n "$n" "$AUDIT_LOG"; }

espacio() {
  echo "Total de $LOG_BASE: $(du -sh "$LOG_BASE" 2>/dev/null | cut -f1)   (disco al $(df --output=pcent "$LOG_BASE" | tail -1 | tr -d ' '))"
  echo "== Los 8 archivos más grandes"; find "$LOG_BASE" -type f -printf '%s %p\n' 2>/dev/null | sort -rn | head -8 | awk '{printf "%8.1f MB  %s\n", $1/1048576, $2}'
  if hay_journal; then journalctl --disk-usage; fi
}

rotar() {
  [[ ${1:-} == "--si" ]] && SI=true
  confirmar "Se forzará la rotación de logs y se borrará el journal de más de 14 días."
  logrotate -f /etc/logrotate.conf && log INFO "Rotación ejecutada."
  if hay_journal; then journalctl --vacuum-time=14d >/dev/null 2>&1 && log INFO "Journal limpiado (más de 14 días)."; fi
  auditar "logs: rotación forzada"
}

configurar_rotacion() {
  local tmp; tmp="$(mktemp)"
  cat > "$tmp" << CONF
$AUDIT_LOG $LOG_BASE/respaldo_sistema.log {
    weekly
    rotate 12
    compress
    delaycompress
    missingok
    notifempty
    create 640 root adm
}
CONF
  # Primero se valida; solo si es correcta se instala
  if ! logrotate -d "$tmp" >/dev/null 2>&1; then rm -f "$tmp"; fail "La configuración de rotación generada tiene errores; no se instaló."; fi
  install -m 644 "$tmp" /etc/logrotate.d/sigeru-admin; rm -f "$tmp"
  auditar "logs: instalada rotación de logs de SiGeRU"; log INFO "Rotación instalada en /etc/logrotate.d/sigeru-admin (semanal, 12 copias)."
}

resumen() {
  local uso fallos="n/d" hoy ayer
  uso="$(df --output=pcent "$LOG_BASE" 2>/dev/null | tail -1 | tr -dc '0-9')"
  hoy="$(date '+%F')|$(date '+%b %e')|$(date '+%b %d')"; ayer="$(date -d yesterday '+%F')|$(date -d yesterday '+%b %e')|$(date -d yesterday '+%b %d')"
  if [[ -f ${LOGS[auth]} ]] || hay_journal; then
    fallos="$(lineas_auth 2>/dev/null | grep -E 'Failed password|Invalid user' | grep -cE "$hoy|$ayer" || true)"
  fi
  if [[ ${uso:-0} -ge 90 ]]; then echo "[!!] logs: el disco de logs está al ${uso}%"
  elif [[ $fallos =~ ^[0-9]+$ && $fallos -ge 50 ]]; then echo "[!!] logs: $fallos intentos fallidos de SSH (hoy y ayer); revise: admin.sh logs fallidos"
  elif [[ $fallos == "n/d" ]]; then echo "[OK] logs: disco al ${uso:-?}% (sin registro de autenticación disponible para revisar)"
  else echo "[OK] logs: disco al ${uso:-?}%, ${fallos} intento(s) fallido(s) de SSH (hoy y ayer)"; fi
}

accion="${1:-}"; [[ $# -gt 0 ]] && shift
case "$accion" in
  resumen) resumen ;;
  listar|ver|errores|accesos|fallidos|buscar|auditoria|espacio|rotar|configurar-rotacion)
    exigir_root
    case "$accion" in
      listar) listar ;; ver) ver "$@" ;; errores) errores "$@" ;; accesos) accesos "$@" ;; fallidos) fallidos "$@" ;;
      buscar) buscar "$@" ;; auditoria) auditoria "$@" ;; espacio) espacio ;; rotar) rotar "$@" ;; configurar-rotacion) configurar_rotacion ;;
    esac ;;
  *) fail "Uso: logs listar | ver | errores | accesos | fallidos | buscar | auditoria | espacio | rotar | configurar-rotacion" ;;
esac
