#!/usr/bin/env bash
# =============================================================================
# redes/redes.sh - Gestión de redes del servidor (se usa desde admin.sh)
#   admin.sh redes estado                    interfaces, IP, puerta de enlace, DNS y conectividad
#   admin.sh redes puertos                   puertos en escucha y qué programa los usa
#   admin.sh redes conexiones                conexiones establecidas por IP remota
#   admin.sh redes probar HOST [PUERTO]      ping y, si se indica, prueba de puerto TCP
#   admin.sh redes verificar                 controla los servidores de redes/servidores.conf
#   admin.sh redes hosts | hosts-agregar IP NOMBRE
#   admin.sh redes configurar --interfaz I --ip A.B.C.D/N --gateway G [--dns D1,D2] [--aplicar]
# "configurar" sin --aplicar solo genera y valida la configuración (no toca la red).
# =============================================================================
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=../lib/utils.sh
source "${SCRIPT_DIR}/../lib/utils.sh"
SERVIDORES_CONF="${SERVIDORES_CONF:-${SCRIPT_DIR}/servidores.conf}"
NETPLAN_DIR="${NETPLAN_DIR:-/etc/netplan}"
NETPLAN_BIN="${NETPLAN_BIN:-netplan}"   # (se cambia solo para pruebas)

gateway_actual() { ip route show default 2>/dev/null | awk 'NR==1{print $3}'; }
dns_actual()     { { resolvectl dns 2>/dev/null | awk -F': ' 'NF>1{print $2}' | tr ' ' '\n'; grep '^nameserver' /etc/resolv.conf 2>/dev/null | awk '{print $2}'; } | grep -vx '' | grep -v '^127\.' | sort -u | paste -sd' ' - ; }
responde()       { ping -c 1 -W 2 "$1" >/dev/null 2>&1; }
puerto_abierto() { timeout 3 bash -c "exec 3<>/dev/tcp/$1/$2" 2>/dev/null; }

estado() {
  echo "== Interfaces"; ip -br addr
  local gw dns; gw="$(gateway_actual)"; dns="$(dns_actual)"
  echo "== Puerta de enlace: ${gw:-no definida}"; echo "== DNS: ${dns:-no definido}"
  echo "== Conectividad"
  if [[ -n $gw ]] && responde "$gw"; then echo "  [OK] puerta de enlace $gw"; else echo "  [!!] sin respuesta de la puerta de enlace"; fi
  if responde 8.8.8.8; then echo "  [OK] salida a Internet (8.8.8.8)"; else echo "  [!!] sin salida a Internet"; fi
  if getent hosts ubuntu.com >/dev/null 2>&1; then echo "  [OK] resolución de nombres (DNS)"; else echo "  [!!] no resuelve nombres"; fi
}

puertos() { echo "== Puertos en escucha"; ss -tulnp | awk 'NR==1 || /LISTEN|UNCONN/'; }
conexiones() {
  echo "== Resumen"; ss -s | head -3
  echo "== Conexiones establecidas por IP remota (top 10)"
  ss -tnH state established 2>/dev/null | awk '{print $4}' | sed -E 's/:[0-9]+$//' | sort | uniq -c | sort -rn | head -10
}

probar() {
  local host="${1:?Uso: redes probar HOST [PUERTO]}" puerto="${2:-}"
  if responde "$host"; then echo "[OK] ping a $host"; else echo "[!!] $host no responde al ping"; fi
  if [[ -n $puerto ]]; then
    validar_puerto "$puerto"
    if puerto_abierto "$host" "${puerto%%/*}"; then echo "[OK] puerto $puerto abierto en $host"; else echo "[!!] puerto $puerto cerrado o filtrado en $host"; fi
  fi
}

verificar() {
  [[ -f $SERVIDORES_CONF ]] || fail "No se encuentra $SERVIDORES_CONF"
  local nombre ip fallas=0
  printf '%-16s %-15s %-8s %s\n' SERVIDOR IP PING SSH
  while read -r nombre ip _; do
    [[ -z ${nombre:-} || $nombre == \#* ]] && continue
    validar_ip "$ip"
    local p="no" s="no"
    responde "$ip" && p="sí"; puerto_abierto "$ip" 22 && s="sí"
    [[ $p == "sí" ]] || fallas=$((fallas + 1))
    printf '%-16s %-15s %-8s %s\n' "$nombre" "$ip" "$p" "$s"
  done < "$SERVIDORES_CONF"
  [[ $fallas -eq 0 ]] || { log WARN "$fallas servidor(es) sin respuesta."; return 1; }
}

hosts_listar() { grep -v '^\s*#' /etc/hosts | grep -v '^\s*$'; }
hosts_agregar() {
  local ip="${1:?Uso: redes hosts-agregar IP NOMBRE}" nombre="${2:?Uso: redes hosts-agregar IP NOMBRE}"
  validar_ip "$ip"; [[ $nombre =~ ^[a-zA-Z0-9][a-zA-Z0-9.-]{0,62}$ ]] || fail "Nombre de host inválido: $nombre"
  grep -qE "(^|[[:space:]])$nombre([[:space:]]|$)" /etc/hosts && fail "'$nombre' ya figura en /etc/hosts."
  cp -p /etc/hosts "/etc/hosts.bak-$(date +%Y%m%d_%H%M%S)"
  printf '%s\t%s\n' "$ip" "$nombre" >> /etc/hosts
  auditar "redes: /etc/hosts agrega $ip $nombre"; log INFO "Agregado a /etc/hosts: $ip $nombre"
}

configurar() {
  local iface="" ip="" gw="" dns="8.8.8.8,8.8.4.4" aplicar=false
  while [[ $# -gt 0 ]]; do
    case "$1" in
      --interfaz) iface="${2:?}"; shift 2 ;; --ip) ip="${2:?}"; shift 2 ;; --gateway) gw="${2:?}"; shift 2 ;;
      --dns) dns="${2:?}"; shift 2 ;; --aplicar) aplicar=true; shift ;; --si) SI=true; shift ;;
      *) fail "Opción desconocida: $1" ;;
    esac
  done
  [[ -n $iface && -n $ip && -n $gw ]] || fail "Uso: redes configurar --interfaz I --ip A.B.C.D/N --gateway G [--dns D1,D2] [--aplicar]"
  [[ $iface =~ ^[a-zA-Z0-9._-]{1,15}$ ]] || fail "Interfaz inválida: $iface"
  [[ $ip =~ ^[0-9.]+/([0-9]|[12][0-9]|3[0-2])$ ]] || fail "La IP debe incluir la máscara, por ejemplo 192.168.5.14/24"
  validar_ip "${ip%/*}"; validar_ip "$gw"
  local d; for d in ${dns//,/ }; do validar_ip "$d"; done
  local yaml; yaml="network:
  version: 2
  ethernets:
    $iface:
      dhcp4: no
      addresses: [$ip]
      routes:
        - to: default
          via: $gw
      nameservers:
        addresses: [${dns//,/, }]"
  # Se valida SIEMPRE en una carpeta temporal, sin tocar la red real
  local tmp; tmp="$(mktemp -d)"
  # shellcheck disable=SC2064  # se expande ahora a propósito: "tmp" es local y no existiría al salir
  trap "rm -rf '$tmp'" EXIT
  mkdir -p "$tmp/etc/netplan"; echo "$yaml" > "$tmp/etc/netplan/60-sigeru.yaml"; chmod 600 "$tmp/etc/netplan/60-sigeru.yaml"
  netplan generate --root-dir "$tmp" >/dev/null 2>&1 || fail "netplan rechazó la configuración generada (revise interfaz, IP y puerta de enlace)."
  echo "$yaml"; log INFO "Configuración válida."
  $aplicar || { log INFO "No se aplicó nada (use --aplicar para hacerlo)."; return 0; }
  confirmar "Se reemplazará la configuración de red de este servidor. Si queda mal puede perder la conexión SSH." "SI"
  local copia; copia="$NETPLAN_DIR/respaldo-$(date +%Y%m%d_%H%M%S)"
  mkdir -p "$copia"; mv "$NETPLAN_DIR"/*.yaml "$copia"/ 2>/dev/null || true
  echo "$yaml" > "$NETPLAN_DIR/60-sigeru.yaml"; chmod 600 "$NETPLAN_DIR/60-sigeru.yaml"
  auditar "redes: configurada $iface con $ip (copia anterior en $copia)"
  log INFO "Configuración anterior guardada en $copia. Aplicando con 'netplan try' (se revierte sola si no confirma en 60 s)..."
  "$NETPLAN_BIN" try --timeout 60
}

resumen() {
  local gw dns ip_ok
  ip_ok="$(ip -4 -br addr 2>/dev/null | awk '$1!="lo" && $2=="UP" {print $1"="$3; exit}')"
  gw="$(gateway_actual)"
  if [[ -z $ip_ok ]]; then echo "[!!] redes: ninguna interfaz con IPv4 activa"; return; fi
  if [[ -z $gw ]]; then echo "[!!] redes: $ip_ok pero sin puerta de enlace"; return; fi
  if ! responde "$gw"; then echo "[!!] redes: $ip_ok, la puerta de enlace $gw no responde"; return; fi
  if getent hosts ubuntu.com >/dev/null 2>&1; then dns="DNS ok"; else dns="DNS sin respuesta"; fi
  [[ $dns == "DNS ok" ]] && echo "[OK] redes: $ip_ok, puerta de enlace $gw, $dns" || echo "[!!] redes: $ip_ok, puerta de enlace $gw, $dns"
}

accion="${1:-}"; [[ $# -gt 0 ]] && shift
case "$accion" in
  resumen) resumen ;;
  estado|puertos|conexiones|probar|verificar|hosts|hosts-agregar|configurar)
    case "$accion" in estado|puertos|conexiones|probar|verificar|hosts) : ;; *) exigir_root ;; esac
    case "$accion" in
      estado) estado ;; puertos) puertos ;; conexiones) conexiones ;; probar) probar "$@" ;; verificar) verificar ;;
      hosts) hosts_listar ;; hosts-agregar) hosts_agregar "$@" ;; configurar) configurar "$@" ;;
    esac ;;
  *) fail "Uso: redes estado | puertos | conexiones | probar | verificar | hosts | hosts-agregar | configurar" ;;
esac
