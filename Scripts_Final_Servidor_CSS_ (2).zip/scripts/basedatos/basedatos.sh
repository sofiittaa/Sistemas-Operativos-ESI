#!/usr/bin/env bash
# =============================================================================
# basedatos/basedatos.sh - Gestión de bases de datos MySQL (se usa desde admin.sh)
#   admin.sh basedatos estado | listar | tamanios
#   admin.sh basedatos crear BASE
#   admin.sh basedatos eliminar BASE [--si]        (hace un respaldo antes de borrar)
#   admin.sh basedatos usuarios
#   admin.sh basedatos usuario-crear USUARIO BASE [--host H] [--solo-lectura]
#   admin.sh basedatos usuario-clave USUARIO [--host H]
#   admin.sh basedatos usuario-eliminar USUARIO [--host H] [--si]
#   admin.sh basedatos permisos USUARIO [--host H]
# Respaldar y restaurar la base se hace con los comandos de "admin.sh backup".
# La conexión usa un archivo de credenciales (nunca se pasa la clave por línea de comandos):
#   MYSQL_DEFAULTS_FILE, o backup/mysql_defaults.cnf (el que ya usa backup_db.sh), o /root/.my.cnf
# =============================================================================
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=../lib/utils.sh
source "${SCRIPT_DIR}/../lib/utils.sh"
DIR_PREVIO="${DIR_PREVIO:-/var/backups/sigeru-bd}"
BD_SISTEMA="information_schema performance_schema mysql sys"

buscar_credenciales() {
  local c
  for c in "${MYSQL_DEFAULTS_FILE:-}" "${SCRIPT_DIR}/../backup/mysql_defaults.cnf" /root/.my.cnf; do
    [[ -n $c && -f $c ]] && { echo "$c"; return 0; }
  done
  return 1
}
CRED="$(buscar_credenciales || true)"
sql() {        # sql "consulta" -> filas separadas por tabulación, sin encabezados
  mysql --defaults-extra-file="$CRED" -N -B -e "$1"
}
sql_stdin() { mysql --defaults-extra-file="$CRED"; }   # el SQL entra por stdin: la clave nunca aparece en 'ps'
preparar() {
  command -v mysql >/dev/null || fail "No está instalado el cliente de MySQL (mysql)."
  [[ -n $CRED ]] || fail "No hay archivo de credenciales (defina MYSQL_DEFAULTS_FILE o cree backup/mysql_defaults.cnf)."
  sql "SELECT 1" >/dev/null 2>&1 || fail "No se pudo conectar a MySQL con $CRED (¿servicio apagado o credenciales incorrectas?)."
}
validar_bd() {
  [[ $1 =~ ^[A-Za-z0-9_]{1,64}$ ]] || fail "Nombre de base inválido: '$1' (letras, números y _)."
}
es_sistema() { [[ " $BD_SISTEMA " == *" $1 "* ]]; }
validar_usuario_bd() { [[ $1 =~ ^[A-Za-z0-9_.-]{1,32}$ ]] || fail "Nombre de usuario inválido: '$1'."; }
validar_host() { [[ $1 =~ ^[A-Za-z0-9_.%:-]{1,60}$ ]] || fail "Host inválido: '$1'."; }
existe_bd() { [[ "$(sql "SELECT COUNT(*) FROM information_schema.schemata WHERE schema_name='$1'")" -gt 0 ]]; }
existe_usr() { [[ "$(sql "SELECT COUNT(*) FROM mysql.user WHERE user='$1' AND host='$2'")" -gt 0 ]]; }

estado() {
  echo "Versión:        $(sql 'SELECT VERSION()')"
  echo "Conexiones:     $(sql "SHOW STATUS LIKE 'Threads_connected'" | awk '{print $2}') activas (máximo permitido: $(sql "SELECT @@max_connections"))"
  echo "Tiempo activo:  $(sql "SHOW STATUS LIKE 'Uptime'" | awk '{printf "%d horas", $2/3600}')"
  echo "Bases de datos: $(sql "SELECT COUNT(*) FROM information_schema.schemata WHERE schema_name NOT IN ('information_schema','performance_schema','mysql','sys')") (sin contar las del sistema)"
}
listar() { sql "SELECT schema_name FROM information_schema.schemata ORDER BY 1"; }
tamanios() {
  printf '%-24s %10s %8s\n' BASE "MB" TABLAS
  sql "SELECT table_schema, ROUND(SUM(data_length+index_length)/1024/1024,2), COUNT(*) FROM information_schema.tables GROUP BY table_schema ORDER BY 2 DESC" |
    awk -F'\t' '{printf "%-24s %10s %8s\n",$1,$2,$3}'
}
crear() {
  validar_bd "${1:?Uso: basedatos crear BASE}"; existe_bd "$1" && fail "La base ya existe: $1"
  echo "CREATE DATABASE \`$1\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;" | sql_stdin
  auditar "basedatos: creada $1"; log INFO "Base creada: $1"
}
eliminar() {
  local b="${1:?Uso: basedatos eliminar BASE}"; shift
  [[ ${1:-} == "--si" ]] && SI=true
  validar_bd "$b"; es_sistema "$b" && fail "'$b' es una base del sistema."
  existe_bd "$b" || fail "La base no existe: $b"
  confirmar "Se ELIMINARÁ la base $b con todos sus datos (antes se guarda una copia)." "$b"
  install -d -m 700 "$DIR_PREVIO"
  local copia; copia="$DIR_PREVIO/${b}_$(date +%Y%m%d_%H%M%S).sql.gz"
  mysqldump --defaults-extra-file="$CRED" --single-transaction --routines --triggers "$b" | gzip > "$copia"
  gzip -t "$copia" || fail "No se pudo generar la copia previa; no se borra nada."
  echo "DROP DATABASE \`$b\`;" | sql_stdin
  auditar "basedatos: eliminada $b (copia previa: $copia)"; log INFO "Base eliminada: $b. Copia previa en $copia"
}
usuarios() {
  printf '%-24s %s\n' USUARIO HOST
  sql "SELECT user, host FROM mysql.user WHERE user NOT IN ('mysql.sys','mysql.session','mysql.infoschema','mariadb.sys','debian-sys-maint','') ORDER BY 1,2" |
    awk -F'\t' '{printf "%-24s %s\n",$1,$2}'
}
usuario_crear() {
  local u="${1:?Uso: basedatos usuario-crear USUARIO BASE [--host H] [--solo-lectura]}" b="${2:?Falta la base}"; shift 2
  local host="localhost" permisos="ALL PRIVILEGES" pass
  while [[ $# -gt 0 ]]; do
    case "$1" in --host) host="${2:?}"; shift 2 ;; --solo-lectura) permisos="SELECT"; shift ;; *) fail "Opción desconocida: $1" ;; esac
  done
  validar_usuario_bd "$u"; validar_bd "$b"; validar_host "$host"
  [[ $u != root ]] || fail "No se administra el usuario root desde este módulo."
  existe_bd "$b" || fail "La base no existe: $b"
  existe_usr "$u" "$host" && fail "El usuario $u@$host ya existe (para cambiar la clave: basedatos usuario-clave)."
  pass="$(generar_clave)"
  printf "CREATE USER '%s'@'%s' IDENTIFIED BY '%s';\nGRANT %s ON \`%s\`.* TO '%s'@'%s';\nFLUSH PRIVILEGES;\n" "$u" "$host" "$pass" "$permisos" "$b" "$u" "$host" | sql_stdin
  auditar "basedatos: usuario $u@$host creado con $permisos sobre $b"; log INFO "Usuario creado: $u@$host ($permisos sobre $b)"
  echo "Clave generada (anótela, no se vuelve a mostrar): $pass"
}
usuario_clave() {
  local u="${1:?Uso: basedatos usuario-clave USUARIO [--host H]}"; shift; local host="localhost" pass
  [[ ${1:-} == "--host" ]] && host="${2:?}"
  validar_usuario_bd "$u"; validar_host "$host"; existe_usr "$u" "$host" || fail "No existe $u@$host"
  pass="$(generar_clave)"
  printf "ALTER USER '%s'@'%s' IDENTIFIED BY '%s';\nFLUSH PRIVILEGES;\n" "$u" "$host" "$pass" | sql_stdin
  auditar "basedatos: nueva clave para $u@$host"; echo "Nueva clave (no se vuelve a mostrar): $pass"
}
usuario_eliminar() {
  local u="${1:?Uso: basedatos usuario-eliminar USUARIO [--host H]}"; shift; local host="localhost"
  while [[ $# -gt 0 ]]; do case "$1" in --host) host="${2:?}"; shift 2 ;; --si) SI=true; shift ;; *) fail "Opción desconocida: $1" ;; esac; done
  validar_usuario_bd "$u"; validar_host "$host"; [[ $u != root ]] || fail "No se administra el usuario root desde este módulo."
  existe_usr "$u" "$host" || fail "No existe $u@$host"
  confirmar "Se eliminará el usuario de base de datos $u@$host." "$u"
  printf "DROP USER '%s'@'%s';\nFLUSH PRIVILEGES;\n" "$u" "$host" | sql_stdin
  auditar "basedatos: usuario $u@$host eliminado"; log INFO "Usuario eliminado: $u@$host"
}
permisos() {
  local u="${1:?Uso: basedatos permisos USUARIO [--host H]}"; shift; local host="localhost"
  [[ ${1:-} == "--host" ]] && host="${2:?}"
  validar_usuario_bd "$u"; validar_host "$host"; existe_usr "$u" "$host" || fail "No existe $u@$host"
  sql "SHOW GRANTS FOR '$u'@'$host'"
}

resumen() {
  if ! command -v mysql >/dev/null; then echo "[--] basedatos: cliente mysql no instalado en este servidor"; return; fi
  if [[ -z $CRED ]]; then echo "[--] basedatos: sin archivo de credenciales (backup/mysql_defaults.cnf)"; return; fi
  if [[ $EUID -ne 0 ]]; then echo "[--] basedatos: ejecute con sudo para consultar MySQL"; return; fi
  if ! sql "SELECT 1" >/dev/null 2>&1; then echo "[!!] basedatos: no se pudo conectar a MySQL"; return; fi
  local n tiene="sin base sigeru"; n="$(sql "SELECT COUNT(*) FROM information_schema.schemata WHERE schema_name NOT IN ('information_schema','performance_schema','mysql','sys')")"
  existe_bd sigeru && tiene="base sigeru presente"
  [[ $tiene == "base sigeru presente" ]] && echo "[OK] basedatos: MySQL $(sql 'SELECT VERSION()' | cut -d- -f1), $n base(s), $tiene" || echo "[!!] basedatos: MySQL activo, $n base(s), $tiene"
}

accion="${1:-}"; [[ $# -gt 0 ]] && shift
case "$accion" in
  resumen) resumen ;;
  estado|listar|tamanios|crear|eliminar|usuarios|usuario-crear|usuario-clave|usuario-eliminar|permisos)
    exigir_root; preparar
    case "$accion" in
      estado) estado ;; listar) listar ;; tamanios) tamanios ;; crear) crear "$@" ;; eliminar) eliminar "$@" ;; usuarios) usuarios ;;
      usuario-crear) usuario_crear "$@" ;; usuario-clave) usuario_clave "$@" ;; usuario-eliminar) usuario_eliminar "$@" ;; permisos) permisos "$@" ;;
    esac ;;
  *) fail "Uso: basedatos estado | listar | tamanios | crear | eliminar | usuarios | usuario-crear | usuario-clave | usuario-eliminar | permisos" ;;
esac
