#!/usr/bin/env bash
# =============================================================================
# grupos/grupos.sh - Gestión de grupos del servidor (se usa desde admin.sh)
#   admin.sh grupos listar
#   admin.sh grupos miembros GRUPO
#   admin.sh grupos crear GRUPO
#   admin.sh grupos eliminar GRUPO [--si]
#   admin.sh grupos agregar USUARIO GRUPO | quitar USUARIO GRUPO
#   admin.sh grupos inicializar     (crea los grupos del proyecto: sigeru-admin, sigeru-dev, sigeru-soporte)
# =============================================================================
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=../lib/utils.sh
source "${SCRIPT_DIR}/../lib/utils.sh"

GID_MIN="$(awk '/^GID_MIN/{print $2}' /etc/login.defs 2>/dev/null || true)"; GID_MIN="${GID_MIN:-1000}"
GRUPOS_PROYECTO=(sigeru-admin sigeru-dev sigeru-soporte)

existe_g() { getent group "$1" >/dev/null; }
gid_de()   { getent group "$1" | cut -d: -f3; }
miembros() { getent group "$1" | cut -d: -f4 | tr ',' ' '; }
primario_de() { local gid; gid="$(gid_de "$1")"; getent passwd | awk -F: -v g="$gid" '$4==g {print $1}' | paste -sd' ' -; }
protegido() { local gid; gid="$(gid_de "$1")"; [[ $gid -lt $GID_MIN || $1 == sudo ]]; }

listar() {
  printf '%-20s %-7s %s\n' GRUPO GID MIEMBROS
  getent group | awk -F: -v m="$GID_MIN" '($3>=m && $3<60000) || $1=="sudo" {print $1":"$3":"$4}' | sort |
    while IFS=: read -r g id m; do printf '%-20s %-7s %s\n' "$g" "$id" "${m//,/ }"; done
}

mostrar_miembros() {
  existe_g "${1:?Falta el grupo}" || fail "El grupo no existe: $1"
  echo "Miembros de $1: $(miembros "$1")"
  echo "Usuarios que lo tienen como grupo principal: $(primario_de "$1")"
}

crear() {
  validar_nombre "${1:?Uso: grupos crear GRUPO}"
  ! existe_g "$1" || fail "El grupo ya existe: $1"
  groupadd "$1"; auditar "grupos: creado $1"; log INFO "Grupo creado: $1"
}

eliminar() {
  local g="${1:?Uso: grupos eliminar GRUPO}"; shift
  [[ ${1:-} == "--si" ]] && SI=true
  existe_g "$g" || fail "El grupo no existe: $g"
  ! protegido "$g" || fail "'$g' es un grupo del sistema y no se puede eliminar."
  [[ -z "$(primario_de "$g")" ]] || fail "'$g' es el grupo principal de: $(primario_de "$g"). Cambie primero el grupo de esos usuarios."
  confirmar "Se eliminará el grupo $g (miembros: $(miembros "$g"))." "$g"
  groupdel "$g"; auditar "grupos: eliminado $g"; log INFO "Grupo eliminado: $g"
}

agregar() {
  local u="${1:?Uso: grupos agregar USUARIO GRUPO}" g="${2:?Uso: grupos agregar USUARIO GRUPO}"
  id "$u" >/dev/null 2>&1 || fail "El usuario no existe: $u"; existe_g "$g" || fail "El grupo no existe: $g"
  [[ "$(id -u "$u")" -ge 1000 ]] || fail "Solo se administran usuarios comunes."
  usermod -aG "$g" "$u"; auditar "grupos: $u agregado a $g"; log INFO "$u agregado a $g"
}

quitar() {
  local u="${1:?Uso: grupos quitar USUARIO GRUPO}" g="${2:?Uso: grupos quitar USUARIO GRUPO}"
  id "$u" >/dev/null 2>&1 || fail "El usuario no existe: $u"; existe_g "$g" || fail "El grupo no existe: $g"
  [[ " $(miembros "$g") " == *" $u "* ]] || fail "$u no es miembro de $g."
  if [[ $g == sudo && "$(miembros sudo | wc -w)" -le 1 ]]; then fail "$u es el único con sudo: cree otro administrador antes."; fi
  gpasswd -d "$u" "$g" >/dev/null; auditar "grupos: $u retirado de $g"; log INFO "$u retirado de $g"
}

inicializar() {
  local g
  for g in "${GRUPOS_PROYECTO[@]}"; do
    if existe_g "$g"; then log INFO "Ya existía: $g"; else groupadd "$g"; auditar "grupos: creado $g"; log INFO "Grupo creado: $g"; fi
  done
}

resumen() {
  local faltan=() g n
  for g in "${GRUPOS_PROYECTO[@]}"; do existe_g "$g" || faltan+=("$g"); done
  n="$(getent group | awk -F: -v m="$GID_MIN" '$3>=m && $3<60000' | wc -l)"
  if [[ ${#faltan[@]} -gt 0 ]]; then echo "[!!] grupos: faltan grupos del proyecto (${faltan[*]}); ejecute: admin.sh grupos inicializar"
  else echo "[OK] grupos: $n grupo(s) de usuarios, grupos del proyecto presentes (${#GRUPOS_PROYECTO[@]}/${#GRUPOS_PROYECTO[@]})"; fi
}

accion="${1:-}"; [[ $# -gt 0 ]] && shift
case "$accion" in
  resumen) resumen ;;
  listar|miembros|crear|eliminar|agregar|quitar|inicializar)
    exigir_root
    case "$accion" in
      listar) listar ;; miembros) mostrar_miembros "$@" ;; crear) crear "$@" ;; eliminar) eliminar "$@" ;;
      agregar) agregar "$@" ;; quitar) quitar "$@" ;; inicializar) inicializar ;;
    esac ;;
  *) fail "Uso: grupos listar | miembros | crear | eliminar | agregar | quitar | inicializar" ;;
esac
